import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  ScrollView,
  ActivityIndicator,
  Dimensions,
  TouchableOpacity,
} from 'react-native';
import { useLocalSearchParams, router } from 'expo-router';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { useTheme } from '@/contexts/ThemeContext';
import { Star, Heart, ArrowLeft, User as UserIcon, Crown, Lock } from 'lucide-react-native';

interface UserProfile {
  id: string;
  username: string;
  avatar_url: string | null;
  created_at: string;
  gender_identities?: string[];
  interested_in_genders?: string[];
  gender_display?: string;
  custom_gender?: string;
  custom_orientation?: string;
  pronouns?: string;
}

interface FeetPic {
  id: string;
  image_url: string;
  ai_rating: number;
  human_rating_avg: number | null;
  human_rating_count: number;
  created_at: string;
}

const { width } = Dimensions.get('window');
const imageWidth = (width - 48) / 2;

export default function UserProfileScreen() {
  const { id } = useLocalSearchParams();
  const { user, profile: currentUserProfile, loading: authLoading } = useAuth();
  const { theme } = useTheme();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [pics, setPics] = useState<FeetPic[]>([]);
  const [loading, setLoading] = useState(true);
  const [canViewProfile, setCanViewProfile] = useState(false);

  useEffect(() => {
    if (!authLoading && user && currentUserProfile) {
      fetchUserProfile();
    } else if (!authLoading && (!user || !currentUserProfile)) {
      setLoading(false);
    }
  }, [id, user, currentUserProfile, authLoading]);

  const fetchUserProfile = async () => {
    if (!id || !user || !currentUserProfile) {
      setLoading(false);
      return;
    }

    const isOwnProfile = user.id === id;
    const isPremium = currentUserProfile.is_premium === true;
    const hasAccess = isOwnProfile || isPremium;

    console.log('Profile Access Check:', {
      viewingUserId: user.id,
      targetUserId: id,
      isOwnProfile,
      isPremium,
      hasAccess,
    });

    setCanViewProfile(hasAccess);

    const { data: profileData } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', id)
      .single();

    if (profileData) {
      setProfile(profileData);
    }

    if (hasAccess) {
      const { data: picsData } = await supabase
        .from('feet_pics')
        .select('*')
        .eq('user_id', id)
        .order('created_at', { ascending: false });

      if (picsData) {
        setPics(picsData);
      }
    }

    setLoading(false);
  };

  if (loading) {
    return (
      <View style={[styles.loadingContainer, { backgroundColor: theme.background }]}>
        <ActivityIndicator size="large" color={theme.primary} />
      </View>
    );
  }

  if (!profile) {
    return (
      <View style={[styles.container, { backgroundColor: theme.background }]}>
        <View style={[styles.header, { borderBottomColor: theme.border }]}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
            <ArrowLeft size={24} color={theme.text} />
          </TouchableOpacity>
          <Text style={[styles.headerTitle, { color: theme.text }]}>Profile</Text>
          <View style={{ width: 24 }} />
        </View>
        <View style={styles.errorContainer}>
          <Text style={[styles.errorText, { color: theme.text }]}>User not found</Text>
        </View>
      </View>
    );
  }

  if (!canViewProfile) {
    return (
      <View style={[styles.container, { backgroundColor: theme.background }]}>
        <View style={[styles.header, { borderBottomColor: theme.border }]}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
            <ArrowLeft size={24} color={theme.text} />
          </TouchableOpacity>
          <Text style={[styles.headerTitle, { color: theme.text }]}>Profile</Text>
          <View style={{ width: 24 }} />
        </View>

        <ScrollView contentContainerStyle={styles.lockedContent}>
          <View style={styles.profileHeader}>
            {profile.avatar_url ? (
              <Image source={{ uri: profile.avatar_url }} style={styles.avatar} />
            ) : (
              <View style={[styles.avatarPlaceholder, { backgroundColor: theme.tertiaryBackground }]}>
                <UserIcon size={48} color={theme.textTertiary} />
              </View>
            )}
            <Text style={[styles.username, { color: theme.text }]}>{profile.username}</Text>
          </View>

          <View style={[styles.premiumPromptCard, { backgroundColor: theme.surface, borderColor: theme.border }]}>
            <View style={[styles.lockIconContainer, { backgroundColor: theme.primary + '20' }]}>
              <Lock size={48} color={theme.primary} />
            </View>
            <Text style={[styles.premiumPromptTitle, { color: theme.text }]}>Premium Required</Text>
            <Text style={[styles.premiumPromptText, { color: theme.textSecondary }]}>
              Upgrade to premium to view full profiles, photos, and connect with other users.
            </Text>
            <TouchableOpacity
              style={[styles.upgradeButton, { backgroundColor: theme.primary }]}
              onPress={() => router.push('/(tabs)/profile')}
            >
              <Crown size={20} color="#000" />
              <Text style={styles.upgradeButtonText}>Upgrade to Premium</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </View>
    );
  }

  return (
    <View style={[styles.container, { backgroundColor: theme.background }]}>
      <View style={[styles.header, { borderBottomColor: theme.border }]}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <ArrowLeft size={24} color={theme.text} />
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: theme.text }]}>Profile</Text>
        <View style={{ width: 24 }} />
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.profileHeader}>
          {profile.avatar_url ? (
            <Image source={{ uri: profile.avatar_url }} style={styles.avatar} />
          ) : (
            <View style={[styles.avatarPlaceholder, { backgroundColor: theme.tertiaryBackground }]}>
              <UserIcon size={48} color={theme.textTertiary} />
            </View>
          )}
          <Text style={[styles.username, { color: theme.text }]}>{profile.username}</Text>
          <Text style={[styles.joinDate, { color: theme.textSecondary }]}>
            Member since {new Date(profile.created_at).toLocaleDateString()}
          </Text>
        </View>

        {(profile.gender_identities?.length || profile.interested_in_genders?.length || profile.pronouns || profile.custom_orientation) && (
          <View style={[styles.infoSection, { backgroundColor: theme.surface, borderColor: theme.border }]}>
            {profile.gender_identities && profile.gender_identities.length > 0 && (
              <View style={styles.infoItem}>
                <Text style={[styles.infoLabel, { color: theme.textSecondary }]}>Gender Identity</Text>
                <Text style={[styles.infoValue, { color: theme.text }]}>
                  {profile.gender_identities.join(', ')}
                </Text>
              </View>
            )}
            {profile.pronouns && (
              <View style={styles.infoItem}>
                <Text style={[styles.infoLabel, { color: theme.textSecondary }]}>Pronouns</Text>
                <Text style={[styles.infoValue, { color: theme.text }]}>{profile.pronouns}</Text>
              </View>
            )}
            {profile.custom_orientation && (
              <View style={styles.infoItem}>
                <Text style={[styles.infoLabel, { color: theme.textSecondary }]}>Sexual Orientation</Text>
                <Text style={[styles.infoValue, { color: theme.text }]}>{profile.custom_orientation}</Text>
              </View>
            )}
            {profile.interested_in_genders && profile.interested_in_genders.length > 0 && (
              <View style={styles.infoItem}>
                <Text style={[styles.infoLabel, { color: theme.textSecondary }]}>Interested In</Text>
                <Text style={[styles.infoValue, { color: theme.text }]}>
                  {profile.interested_in_genders.join(', ')}
                </Text>
              </View>
            )}
          </View>
        )}

        <View style={styles.statsContainer}>
          <View style={[styles.statBox, { backgroundColor: theme.surface, borderColor: theme.border }]}>
            <Text style={[styles.statValue, { color: theme.text }]}>{pics.length}</Text>
            <Text style={[styles.statLabel, { color: theme.textSecondary }]}>Photos</Text>
          </View>
          <View style={[styles.statBox, { backgroundColor: theme.surface, borderColor: theme.border }]}>
            <Text style={[styles.statValue, { color: theme.text }]}>
              {pics.length > 0
                ? (pics.reduce((sum, pic) => sum + pic.ai_rating, 0) / pics.length).toFixed(1)
                : 'N/A'}
            </Text>
            <Text style={[styles.statLabel, { color: theme.textSecondary }]}>Avg AI Rating</Text>
          </View>
        </View>

        {pics.length === 0 ? (
          <View style={styles.emptyContainer}>
            <Text style={[styles.emptyText, { color: theme.textSecondary }]}>
              No photos yet
            </Text>
          </View>
        ) : (
          <View style={styles.galleryContainer}>
            <Text style={[styles.sectionTitle, { color: theme.text }]}>Gallery</Text>
            <View style={styles.gallery}>
              {pics.map((pic) => (
                <View key={pic.id} style={styles.galleryItem}>
                  <Image source={{ uri: pic.image_url }} style={styles.galleryImage} />
                  <View style={styles.galleryOverlay}>
                    <View style={styles.ratingBadge}>
                      <Star size={12} color="#ffd700" fill="#ffd700" />
                      <Text style={styles.ratingText}>{pic.ai_rating.toFixed(1)}</Text>
                    </View>
                    {pic.human_rating_avg && (
                      <View style={[styles.ratingBadge, styles.humanRatingBadge]}>
                        <Heart size={12} color="#ff3b30" fill="#ff3b30" />
                        <Text style={styles.ratingText}>{pic.human_rating_avg.toFixed(1)}</Text>
                      </View>
                    )}
                  </View>
                </View>
              ))}
            </View>
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    paddingTop: 60,
    paddingBottom: 16,
    paddingHorizontal: 16,
    borderBottomWidth: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  backButton: {
    width: 24,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '600',
  },
  scrollContent: {
    paddingBottom: 32,
  },
  profileHeader: {
    alignItems: 'center',
    paddingVertical: 32,
  },
  avatar: {
    width: 120,
    height: 120,
    borderRadius: 60,
    marginBottom: 16,
  },
  avatarPlaceholder: {
    width: 120,
    height: 120,
    borderRadius: 60,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  username: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  joinDate: {
    fontSize: 14,
  },
  infoSection: {
    marginHorizontal: 16,
    marginBottom: 24,
    padding: 20,
    borderRadius: 16,
    borderWidth: 1,
    gap: 16,
  },
  infoItem: {
    gap: 4,
  },
  infoLabel: {
    fontSize: 12,
    fontWeight: '600',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  infoValue: {
    fontSize: 16,
  },
  statsContainer: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    gap: 12,
    marginBottom: 32,
  },
  statBox: {
    flex: 1,
    padding: 20,
    borderRadius: 16,
    alignItems: 'center',
    borderWidth: 1,
  },
  statValue: {
    fontSize: 32,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 14,
  },
  galleryContainer: {
    paddingHorizontal: 16,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '600',
    marginBottom: 16,
  },
  gallery: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  galleryItem: {
    width: imageWidth,
    aspectRatio: 1,
    position: 'relative',
  },
  galleryImage: {
    width: '100%',
    height: '100%',
    borderRadius: 12,
  },
  galleryOverlay: {
    position: 'absolute',
    bottom: 8,
    left: 8,
    right: 8,
    flexDirection: 'row',
    gap: 6,
  },
  ratingBadge: {
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  humanRatingBadge: {
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
  },
  ratingText: {
    color: '#fff',
    fontSize: 11,
    fontWeight: '600',
  },
  emptyContainer: {
    alignItems: 'center',
    paddingVertical: 60,
  },
  emptyText: {
    fontSize: 16,
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  errorText: {
    fontSize: 18,
  },
  lockedContent: {
    paddingBottom: 32,
    flex: 1,
    justifyContent: 'center',
  },
  premiumPromptCard: {
    marginHorizontal: 24,
    padding: 32,
    borderRadius: 24,
    borderWidth: 1,
    alignItems: 'center',
    gap: 16,
  },
  lockIconContainer: {
    width: 96,
    height: 96,
    borderRadius: 48,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  premiumPromptTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  premiumPromptText: {
    fontSize: 16,
    textAlign: 'center',
    lineHeight: 24,
  },
  upgradeButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 16,
    paddingHorizontal: 32,
    borderRadius: 12,
    marginTop: 8,
  },
  upgradeButtonText: {
    color: '#000',
    fontSize: 16,
    fontWeight: '700',
  },
});
