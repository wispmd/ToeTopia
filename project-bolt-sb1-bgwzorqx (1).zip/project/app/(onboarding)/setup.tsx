import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
} from 'react-native';
import { router } from 'expo-router';
import { supabase } from '@/lib/supabase';
import { useTheme } from '@/contexts/ThemeContext';
import { useAuth } from '@/contexts/AuthContext';

export default function OnboardingSetup() {
  const { theme } = useTheme();
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);

  const handleComplete = async () => {
    setLoading(true);
    await supabase.from('profiles').update({ onboarding_completed: true }).eq('id', user?.id);
    setLoading(false);
    router.replace('/(tabs)');
  };

  return (
    <View style={[styles.container, { backgroundColor: theme.background }]}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.header}>
          <Text style={[styles.title, { color: theme.text }]}>Welcome to Toetopia!</Text>
          <Text style={[styles.subtitle, { color: theme.textSecondary }]}>
            You're all set to start rating and matching.
          </Text>
        </View>
        <View style={[styles.infoBox, { backgroundColor: theme.surface }]}>
          <Text style={[styles.infoText, { color: theme.text }]}>
            ✨ Visit Preferences from your Profile to set your gender identity and matching preferences.
          </Text>
        </View>
        <TouchableOpacity
          style={[styles.button, { backgroundColor: theme.primary }]}
          onPress={handleComplete}
          disabled={loading}
        >
          <Text style={styles.buttonText}>{loading ? 'Getting Started...' : 'Get Started'}</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scrollContent: { padding: 24, paddingTop: 80 },
  header: { marginBottom: 40, alignItems: 'center' },
  title: { fontSize: 32, fontWeight: 'bold', marginBottom: 8, textAlign: 'center' },
  subtitle: { fontSize: 16, lineHeight: 24, textAlign: 'center' },
  infoBox: { borderRadius: 12, padding: 20, marginBottom: 32 },
  infoText: { fontSize: 16, lineHeight: 24, textAlign: 'center' },
  button: { borderRadius: 12, padding: 18, alignItems: 'center', marginTop: 24 },
  buttonText: { color: '#fff', fontSize: 17, fontWeight: '600' },
});
