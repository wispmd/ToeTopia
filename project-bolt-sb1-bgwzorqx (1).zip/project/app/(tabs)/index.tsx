import React, { useEffect, useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  Image,
  ActivityIndicator,
  RefreshControl,
  Dimensions,
  TouchableOpacity,
  Modal,
} from 'react-native';
import { supabase } from '@/lib/supabase';
import { useTheme } from '@/contexts/ThemeContext';
import { Star, Heart, User as UserIcon, X, Footprints } from 'lucide-react-native';
import { router } from 'expo-router';

interface FeetPic {
  id: string;
  image_url: string;
  ai_rating: number;
  human_rating_avg: number | null;
  human_rating_count: number;
  created_at: string;
  user_id: string;
  profiles: {
    username: string;
    avatar_url: string | null;
  };
}

const { width, height } = Dimensions.get('window');

export default function FeedScreen() {
  const { theme, isDark } = useTheme();
  const [pics, setPics] = useState<FeetPic[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [expandedImage, setExpandedImage] = useState<string | null>(null);
  const flatListRef = useRef<FlatList>(null);
  const scrollY = useRef(0);
  const cardHeights = useRef<number[]>([]);

  const fetchPics = async () => {
    const { data, error } = await supabase
      .from('feet_pics')
      .select(
        `
        *,
        profiles:user_id (
          username,
          avatar_url
        )
      `
      )
      .order('created_at', { ascending: false })
      .limit(50);

    if (data) {
      setPics(data as any);
    }
    setLoading(false);
    setRefreshing(false);
  };

  useEffect(() => {
    fetchPics();

    const subscription = supabase
      .channel('feed_updates')
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'feet_pics' },
        (payload) => {
          console.log('New feet pic inserted:', payload);
          fetchPics();
        }
      )
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'feet_pics' },
        (payload) => {
          console.log('Feet pic updated:', payload);
          fetchPics();
        }
      )
      .on(
        'postgres_changes',
        { event: 'DELETE', schema: 'public', table: 'feet_pics' },
        (payload) => {
          console.log('Feet pic deleted:', payload);
          fetchPics();
        }
      )
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'ratings' },
        (payload) => {
          console.log('New rating inserted:', payload);
          fetchPics();
        }
      )
      .subscribe((status) => {
        console.log('Feed subscription status:', status);
      });

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const onRefresh = () => {
    setRefreshing(true);
    fetchPics();
  };

  const CARD_HEIGHT = width + 220;
  const CARD_MARGIN = 24;
  const ITEM_HEIGHT = CARD_HEIGHT + CARD_MARGIN;

  const getItemLayout = (data: any, index: number) => {
    return {
      length: ITEM_HEIGHT,
      offset: ITEM_HEIGHT * index,
      index,
    };
  };

  const renderItem = ({ item, index }: { item: FeetPic; index: number }) => (
    <View style={[styles.card, { backgroundColor: theme.surface, borderColor: theme.border }]}>
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.userInfo}
          onPress={() => router.push(`/user/${item.user_id}`)}
          activeOpacity={0.7}
        >
          {item.profiles?.avatar_url ? (
            <Image
              source={{ uri: item.profiles.avatar_url }}
              style={styles.avatar}
            />
          ) : (
            <View style={[styles.avatarPlaceholder, { backgroundColor: theme.tertiaryBackground }]}>
              <UserIcon size={20} color={theme.textTertiary} />
            </View>
          )}
          <Text style={[styles.username, { color: theme.text }]}>{item.profiles?.username || 'Anonymous'}</Text>
        </TouchableOpacity>
      </View>

      <TouchableOpacity onPress={() => setExpandedImage(item.image_url)} activeOpacity={0.95}>
        <Image
          source={{ uri: item.image_url }}
          style={styles.image}
          resizeMode="cover"
        />
      </TouchableOpacity>

      <View style={styles.ratingsContainer}>
        <View style={styles.ratingBox}>
          <Star size={20} color="#ffd700" fill="#ffd700" />
          <Text style={[styles.ratingLabel, { color: theme.textTertiary }]}>AI Rating</Text>
          <Text style={[styles.ratingValue, { color: theme.text }]}>{item.ai_rating.toFixed(1)}</Text>
        </View>

        <View style={[styles.divider, { backgroundColor: theme.border }]} />

        <View style={styles.ratingBox}>
          <Heart size={20} color="#ff3b30" fill="#ff3b30" />
          <Text style={[styles.ratingLabel, { color: theme.textTertiary }]}>Human Rating</Text>
          <Text style={[styles.ratingValue, { color: theme.text }]}>
            {item.human_rating_avg
              ? item.human_rating_avg.toFixed(1)
              : 'N/A'}
          </Text>
          {item.human_rating_count > 0 && (
            <Text style={[styles.ratingCount, { color: theme.textQuaternary }]}>
              ({item.human_rating_count} ratings)
            </Text>
          )}
        </View>
      </View>
    </View>
  );

  if (loading) {
    return (
      <View style={[styles.loadingContainer, { backgroundColor: theme.background }]}>
        <ActivityIndicator size="large" color={theme.primary} />
      </View>
    );
  }

  return (
    <View style={[styles.container, { backgroundColor: theme.background }]}>
      <View style={styles.headerWrapper}>
        <View style={[styles.titleContainer, { backgroundColor: isDark ? 'rgba(26, 22, 53, 0.95)' : 'rgba(243, 241, 255, 0.98)', borderColor: isDark ? 'transparent' : 'rgba(139, 92, 246, 0.2)' }]}>
          <View style={styles.titleContent}>
            <View style={[styles.iconWrapper, { backgroundColor: theme.primary + '20' }]}>
              <Footprints size={28} color={theme.primary} strokeWidth={2.5} />
            </View>
            <View>
              <Text style={[styles.title, { color: theme.text }]}>Toetopia</Text>
              <Text style={[styles.subtitle, { color: theme.textSecondary }]}>Discover, Rate & Match</Text>
            </View>
          </View>
        </View>
      </View>
      <FlatList
        ref={flatListRef}
        data={pics}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.list}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor={theme.primary}
          />
        }
        snapToInterval={ITEM_HEIGHT}
        decelerationRate="fast"
        snapToAlignment="start"
        getItemLayout={getItemLayout}
        showsVerticalScrollIndicator={false}
        pagingEnabled={false}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Text style={[styles.emptyText, { color: theme.text }]}>No pics yet</Text>
            <Text style={[styles.emptySubtext, { color: theme.textTertiary }]}>
              Be the first to upload!
            </Text>
          </View>
        }
      />

      <Modal visible={!!expandedImage} transparent animationType="fade" onRequestClose={() => setExpandedImage(null)}>
        <TouchableOpacity style={styles.imageExpandModal} activeOpacity={1} onPress={() => setExpandedImage(null)}>
          <View style={styles.imageExpandHeader}>
            <TouchableOpacity style={styles.closeButton} onPress={() => setExpandedImage(null)}>
              <X size={28} color="#fff" />
            </TouchableOpacity>
          </View>
          {expandedImage && <Image source={{ uri: expandedImage }} style={styles.expandedImage} resizeMode="contain" />}
        </TouchableOpacity>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  headerWrapper: {
    paddingTop: 50,
    paddingHorizontal: 16,
    paddingBottom: 16,
  },
  titleContainer: {
    borderRadius: 20,
    padding: 20,
    borderWidth: 1,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 12,
    elevation: 5,
  },
  titleContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
  },
  iconWrapper: {
    width: 52,
    height: 52,
    borderRadius: 26,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#fff',
    letterSpacing: -0.5,
    marginBottom: 2,
  },
  subtitle: {
    fontSize: 13,
    opacity: 0.7,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  list: {
    padding: 16,
    paddingBottom: 100,
  },
  card: {
    borderRadius: 16,
    marginBottom: 24,
    overflow: 'hidden',
    borderWidth: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
  },
  userInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  avatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    marginRight: 12,
  },
  avatarPlaceholder: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  username: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  image: {
    width: '100%',
    height: width - 32,
  },
  ratingsContainer: {
    flexDirection: 'row',
    padding: 20,
  },
  ratingBox: {
    flex: 1,
    alignItems: 'center',
  },
  divider: {
    width: 1,
    marginHorizontal: 16,
  },
  ratingLabel: {
    color: '#888',
    fontSize: 12,
    marginTop: 8,
    marginBottom: 4,
  },
  ratingValue: {
    color: '#fff',
    fontSize: 24,
    fontWeight: 'bold',
  },
  ratingCount: {
    color: '#666',
    fontSize: 11,
    marginTop: 4,
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 80,
  },
  emptyText: {
    color: '#fff',
    fontSize: 20,
    fontWeight: '600',
    marginBottom: 8,
  },
  emptySubtext: {
    color: '#666',
    fontSize: 14,
  },
  imageExpandModal: { flex: 1, backgroundColor: 'rgba(0, 0, 0, 0.95)', justifyContent: 'center', alignItems: 'center' },
  imageExpandHeader: { position: 'absolute', top: 60, right: 16, zIndex: 1 },
  closeButton: { width: 44, height: 44, borderRadius: 22, backgroundColor: 'rgba(0, 0, 0, 0.5)', justifyContent: 'center', alignItems: 'center' },
  expandedImage: { width: '100%', height: '100%' },
});
