import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
} from 'react-native';
import { router } from 'expo-router';
import { supabase } from '@/lib/supabase';
import { useTheme } from '@/contexts/ThemeContext';
import { useAuth } from '@/contexts/AuthContext';
import { ArrowLeft, Save, Check, Settings } from 'lucide-react-native';

const GENDER_OPTIONS = [
  { value: 'man', label: 'Man' },
  { value: 'woman', label: 'Woman' },
  { value: 'non-binary', label: 'Non-binary' },
  { value: 'trans-man', label: 'Trans man' },
  { value: 'trans-woman', label: 'Trans woman' },
  { value: 'genderqueer', label: 'Genderqueer' },
  { value: 'self-describe', label: 'Prefer to self-describe' },
  { value: 'prefer-not-to-say', label: 'Prefer not to say' },
];

const DISPLAY_OPTIONS = [
  { value: 'man', label: 'Man' },
  { value: 'woman', label: 'Woman' },
  { value: 'non-binary', label: 'Non-binary' },
];

const INTERESTED_OPTIONS = [
  { value: 'men', label: 'Men' },
  { value: 'women', label: 'Women' },
  { value: 'non-binary-people', label: 'Non-binary people' },
  { value: 'everyone', label: 'Everyone' },
  { value: 'self-describe', label: 'Prefer to self-describe' },
];

const PRONOUN_OPTIONS = [
  { value: 'he/him', label: 'He/Him' },
  { value: 'she/her', label: 'She/Her' },
  { value: 'they/them', label: 'They/Them' },
  { value: 'other', label: 'Other' },
];

export default function PreferencesScreen() {
  const { theme, isDark } = useTheme();
  const { user, profile, refreshProfile } = useAuth();
  const [genderIdentities, setGenderIdentities] = useState<string[]>([]);
  const [genderDisplay, setGenderDisplay] = useState<string>('');
  const [interestedIn, setInterestedIn] = useState<string[]>([]);
  const [pronouns, setPronouns] = useState<string>('');
  const [customGender, setCustomGender] = useState('');
  const [customOrientation, setCustomOrientation] = useState('');
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  useEffect(() => {
    if (profile) {
      setGenderIdentities(profile.gender_identities || []);
      setGenderDisplay(profile.gender_display || '');
      setInterestedIn(profile.interested_in_genders || []);
      setPronouns(profile.pronouns || '');
      setCustomGender(profile.custom_gender || '');
      setCustomOrientation(profile.custom_orientation || '');
    }
  }, [profile]);

  const toggleSelection = (value: string, currentList: string[], setter: (list: string[]) => void) => {
    if (currentList.includes(value)) {
      setter(currentList.filter(v => v !== value));
    } else {
      setter([...currentList, value]);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    setMessage(null);

    try {
      const { error } = await supabase
        .from('profiles')
        .update({
          gender_identities: genderIdentities,
          gender_display: genderDisplay || null,
          interested_in_genders: interestedIn,
          pronouns: pronouns || null,
          custom_gender: customGender || null,
          custom_orientation: customOrientation || null,
        })
        .eq('id', user?.id);

      if (error) throw error;

      await refreshProfile();
      setMessage({ type: 'success', text: 'Preferences saved successfully!' });

      setTimeout(() => {
        router.back();
      }, 1500);
    } catch (error: any) {
      console.error('Save error:', error);
      setMessage({ type: 'error', text: error.message || 'Failed to save preferences' });
    } finally {
      setSaving(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={[styles.container, { backgroundColor: theme.background }]}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <View style={styles.headerWrapper}>
        <View style={[styles.header, { backgroundColor: isDark ? 'rgba(26, 22, 53, 0.95)' : 'rgba(243, 241, 255, 0.98)', borderColor: isDark ? 'transparent' : 'rgba(139, 92, 246, 0.2)' }]}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
            <ArrowLeft size={24} color={theme.text} />
          </TouchableOpacity>
          <View style={styles.titleContent}>
            <View style={[styles.iconWrapper, { backgroundColor: theme.primary + '20' }]}>
              <Settings size={22} color={theme.primary} strokeWidth={2.5} />
            </View>
            <Text style={[styles.headerTitle, { color: theme.text }]}>Preferences</Text>
          </View>
          <View style={{ width: 24 }} />
        </View>
      </View>

      {message && (
        <View style={[styles.messageBanner, message.type === 'error' ? styles.errorBanner : styles.successBanner]}>
          <Text style={styles.messageText}>{message.text}</Text>
        </View>
      )}

      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: theme.text }]}>I identify as...</Text>
          <Text style={[styles.sectionHint, { color: theme.textTertiary }]}>
            You can select multiple options
          </Text>
          <View style={styles.optionsGrid}>
            {GENDER_OPTIONS.map((option) => {
              const isSelected = genderIdentities.includes(option.value);
              return (
                <TouchableOpacity
                  key={option.value}
                  style={[
                    styles.optionButton,
                    {
                      backgroundColor: isSelected ? theme.primary : theme.surface,
                      borderColor: isSelected ? theme.primary : theme.border,
                    }
                  ]}
                  onPress={() => toggleSelection(option.value, genderIdentities, setGenderIdentities)}
                >
                  {isSelected && <Check size={16} color="#fff" style={styles.checkIcon} />}
                  <Text style={[styles.optionText, { color: isSelected ? '#fff' : theme.text }]}>
                    {option.label}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </View>

          {genderIdentities.includes('self-describe') && (
            <TextInput
              style={[styles.customInput, { backgroundColor: theme.surface, color: theme.text, borderColor: theme.border }]}
              placeholder="Describe your gender identity..."
              placeholderTextColor={theme.textTertiary}
              value={customGender}
              onChangeText={setCustomGender}
            />
          )}
        </View>

        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: theme.text }]}>Show me as (optional)</Text>
          <Text style={[styles.sectionHint, { color: theme.textTertiary }]}>
            How you'd like to appear on your profile
          </Text>
          <View style={styles.optionsGrid}>
            {DISPLAY_OPTIONS.map((option) => {
              const isSelected = genderDisplay === option.value;
              return (
                <TouchableOpacity
                  key={option.value}
                  style={[
                    styles.optionButton,
                    {
                      backgroundColor: isSelected ? theme.primary : theme.surface,
                      borderColor: isSelected ? theme.primary : theme.border,
                    }
                  ]}
                  onPress={() => setGenderDisplay(isSelected ? '' : option.value)}
                >
                  {isSelected && <Check size={16} color="#fff" style={styles.checkIcon} />}
                  <Text style={[styles.optionText, { color: isSelected ? '#fff' : theme.text }]}>
                    {option.label}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </View>
        </View>

        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: theme.text }]}>I'm interested in...</Text>
          <Text style={[styles.sectionHint, { color: theme.textTertiary }]}>
            You can select multiple options
          </Text>
          <View style={styles.optionsGrid}>
            {INTERESTED_OPTIONS.map((option) => {
              const isSelected = interestedIn.includes(option.value);
              return (
                <TouchableOpacity
                  key={option.value}
                  style={[
                    styles.optionButton,
                    {
                      backgroundColor: isSelected ? theme.primary : theme.surface,
                      borderColor: isSelected ? theme.primary : theme.border,
                    }
                  ]}
                  onPress={() => toggleSelection(option.value, interestedIn, setInterestedIn)}
                >
                  {isSelected && <Check size={16} color="#fff" style={styles.checkIcon} />}
                  <Text style={[styles.optionText, { color: isSelected ? '#fff' : theme.text }]}>
                    {option.label}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </View>

          {interestedIn.includes('self-describe') && (
            <TextInput
              style={[styles.customInput, { backgroundColor: theme.surface, color: theme.text, borderColor: theme.border }]}
              placeholder="Describe who you're interested in..."
              placeholderTextColor={theme.textTertiary}
              value={customOrientation}
              onChangeText={setCustomOrientation}
            />
          )}
        </View>

        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: theme.text }]}>My pronouns are (optional)</Text>
          <View style={styles.optionsGrid}>
            {PRONOUN_OPTIONS.map((option) => {
              const isSelected = pronouns === option.value;
              return (
                <TouchableOpacity
                  key={option.value}
                  style={[
                    styles.optionButton,
                    {
                      backgroundColor: isSelected ? theme.primary : theme.surface,
                      borderColor: isSelected ? theme.primary : theme.border,
                    }
                  ]}
                  onPress={() => setPronouns(isSelected ? '' : option.value)}
                >
                  {isSelected && <Check size={16} color="#fff" style={styles.checkIcon} />}
                  <Text style={[styles.optionText, { color: isSelected ? '#fff' : theme.text }]}>
                    {option.label}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </View>
        </View>

        <View style={[styles.infoBox, { backgroundColor: theme.tertiaryBackground }]}>
          <Text style={[styles.infoText, { color: theme.textSecondary }]}>
            💡 Your preferences help us match you with compatible people. All fields are optional and can be changed anytime.
          </Text>
        </View>

        <TouchableOpacity
          style={[styles.saveButton, { backgroundColor: theme.primary }]}
          onPress={handleSave}
          disabled={saving}
        >
          {saving ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <>
              <Save size={20} color="#fff" />
              <Text style={styles.saveButtonText}>Save Preferences</Text>
            </>
          )}
        </TouchableOpacity>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  headerWrapper: {
    paddingTop: 50,
    paddingHorizontal: 16,
    paddingBottom: 16,
  },
  header: {
    borderRadius: 20,
    padding: 20,
    borderWidth: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 12,
    elevation: 5,
  },
  titleContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  iconWrapper: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
  },
  backButton: {
    width: 24,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '600',
  },
  messageBanner: {
    padding: 16,
    marginHorizontal: 16,
    marginTop: 16,
    borderRadius: 12,
  },
  successBanner: {
    backgroundColor: '#4CAF50',
  },
  errorBanner: {
    backgroundColor: '#f44336',
  },
  messageText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
    textAlign: 'center',
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 120,
  },
  section: {
    marginBottom: 32,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '700',
    marginBottom: 6,
  },
  sectionHint: {
    fontSize: 14,
    marginBottom: 16,
  },
  optionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  },
  optionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 12,
    borderWidth: 2,
    gap: 8,
  },
  optionText: {
    fontSize: 15,
    fontWeight: '600',
  },
  checkIcon: {
    marginRight: 4,
  },
  customInput: {
    borderWidth: 1,
    borderRadius: 12,
    padding: 16,
    fontSize: 16,
    marginTop: 12,
  },
  infoBox: {
    borderRadius: 12,
    padding: 16,
    marginBottom: 24,
  },
  infoText: {
    fontSize: 14,
    lineHeight: 20,
  },
  saveButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
    borderRadius: 12,
    padding: 18,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  saveButtonText: {
    color: '#fff',
    fontSize: 17,
    fontWeight: '600',
  },
});
