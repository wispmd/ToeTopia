import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Image,
  ActivityIndicator,
} from 'react-native';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { useTheme } from '@/contexts/ThemeContext';
import { MessageCircle, User as UserIcon, Heart } from 'lucide-react-native';
import { router } from 'expo-router';

interface Match {
  id: string;
  user1_id: string;
  user2_id: string;
  created_at: string;
  other_user: {
    id: string;
    username: string;
    avatar_url: string | null;
  };
  unread_count: number;
}

export default function MatchesScreen() {
  const { theme, isDark } = useTheme();
  const [matches, setMatches] = useState<Match[]>([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();

  const fetchMatches = async () => {
    if (!user) return;

    console.log('Fetching matches for user:', user.id);

    const { data: matchesData, error } = await supabase
      .from('matches')
      .select(
        `
        *,
        user1:user1_id (id, username, avatar_url),
        user2:user2_id (id, username, avatar_url)
      `
      )
      .or(`user1_id.eq.${user.id},user2_id.eq.${user.id}`)
      .order('created_at', { ascending: false });

    console.log('Matches data received:', matchesData);
    console.log('Matches error:', error);

    if (matchesData) {
      const matchesWithOtherUser = await Promise.all(
        matchesData.map(async (match: any) => {
          const otherUser =
            match.user1.id === user.id ? match.user2 : match.user1;

          const { count } = await supabase
            .from('messages')
            .select('*', { count: 'exact', head: true })
            .eq('match_id', match.id)
            .eq('read', false)
            .neq('sender_id', user.id);

          return {
            id: match.id,
            user1_id: match.user1_id,
            user2_id: match.user2_id,
            created_at: match.created_at,
            other_user: otherUser,
            unread_count: count || 0,
          };
        })
      );

      console.log('Processed matches:', matchesWithOtherUser);
      setMatches(matchesWithOtherUser);
    }

    setLoading(false);
  };

  useEffect(() => {
    fetchMatches();

    const subscription = supabase
      .channel('matches_changes')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'matches' },
        (payload) => {
          console.log('Match change detected:', payload);
          fetchMatches();
        }
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'messages' },
        (payload) => {
          console.log('Message change detected:', payload);
          fetchMatches();
        }
      )
      .subscribe((status) => {
        console.log('Matches subscription status:', status);
      });

    return () => {
      subscription.unsubscribe();
    };
  }, [user]);

  const renderMatch = ({ item }: { item: Match }) => (
    <TouchableOpacity
      style={styles.matchCard}
      onPress={() => router.push(`/chat/${item.id}`)}
    >
      <View style={styles.matchInfo}>
        {item.other_user.avatar_url ? (
          <Image
            source={{ uri: item.other_user.avatar_url }}
            style={styles.avatar}
          />
        ) : (
          <View style={styles.avatarPlaceholder}>
            <UserIcon size={24} color="#666" />
          </View>
        )}
        <View style={styles.matchDetails}>
          <Text style={styles.matchUsername}>{item.other_user.username}</Text>
          <Text style={styles.matchDate}>
            Matched {new Date(item.created_at).toLocaleDateString()}
          </Text>
        </View>
      </View>
      <View style={styles.matchActions}>
        {item.unread_count > 0 && (
          <View style={styles.unreadBadge}>
            <Text style={styles.unreadText}>{item.unread_count}</Text>
          </View>
        )}
        <MessageCircle size={24} color="#0066ff" />
      </View>
    </TouchableOpacity>
  );

  if (loading) {
    return (
      <View style={[styles.loadingContainer, { backgroundColor: theme.background }]}>
        <ActivityIndicator size="large" color={theme.primary} />
      </View>
    );
  }

  return (
    <View style={[styles.container, { backgroundColor: theme.background }]}>
      <View style={styles.headerWrapper}>
        <View style={[styles.header, { backgroundColor: isDark ? 'rgba(26, 22, 53, 0.95)' : 'rgba(243, 241, 255, 0.98)', borderColor: isDark ? 'transparent' : 'rgba(139, 92, 246, 0.2)' }]}>
          <View style={styles.titleContent}>
            <View style={[styles.iconWrapper, { backgroundColor: '#ff3b30' + '20' }]}>
              <Heart size={26} color="#ff3b30" strokeWidth={2.5} fill="#ff3b30" />
            </View>
            <View>
              <Text style={[styles.title, { color: theme.text }]}>Matches</Text>
              <Text style={[styles.subtitle, { color: theme.textSecondary }]}>
                {matches.length} {matches.length === 1 ? 'match' : 'matches'}
              </Text>
            </View>
          </View>
        </View>
      </View>

      <FlatList
        data={matches}
        renderItem={renderMatch}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.list}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <MessageCircle size={64} color="#333" />
            <Text style={styles.emptyText}>No matches yet</Text>
            <Text style={styles.emptySubtext}>
              Rate other users' pics highly to match
            </Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  headerWrapper: {
    paddingTop: 50,
    paddingHorizontal: 16,
    paddingBottom: 16,
  },
  header: {
    borderRadius: 20,
    padding: 20,
    borderWidth: 1,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 12,
    elevation: 5,
  },
  titleContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
  },
  iconWrapper: {
    width: 52,
    height: 52,
    borderRadius: 26,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#fff',
    letterSpacing: -0.5,
    marginBottom: 2,
  },
  subtitle: {
    fontSize: 13,
    color: '#888',
    opacity: 0.7,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#000',
  },
  list: {
    padding: 16,
    paddingBottom: 100,
  },
  matchCard: {
    backgroundColor: '#1a1a1a',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderWidth: 1,
    borderColor: '#333',
  },
  matchInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  avatar: {
    width: 56,
    height: 56,
    borderRadius: 28,
    marginRight: 16,
  },
  avatarPlaceholder: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: '#333',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  matchDetails: {
    flex: 1,
  },
  matchUsername: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 4,
  },
  matchDate: {
    color: '#888',
    fontSize: 14,
  },
  matchActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  unreadBadge: {
    backgroundColor: '#ff3b30',
    borderRadius: 12,
    minWidth: 24,
    height: 24,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 8,
  },
  unreadText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '700',
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 80,
  },
  emptyText: {
    color: '#fff',
    fontSize: 20,
    fontWeight: '600',
    marginTop: 24,
    marginBottom: 8,
  },
  emptySubtext: {
    color: '#666',
    fontSize: 14,
    textAlign: 'center',
  },
});
