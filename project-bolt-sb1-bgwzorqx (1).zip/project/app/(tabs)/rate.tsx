import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  ActivityIndicator,
  Dimensions,
  ScrollView,
  Alert,
} from 'react-native';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { useTheme } from '@/contexts/ThemeContext';
import { Star, X, Crown, ThumbsUp } from 'lucide-react-native';
import { Platform } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';

interface FeetPic {
  id: string;
  image_url: string;
  ai_rating: number;
  user_id: string;
  profiles: {
    username: string;
  };
}

const { width, height } = Dimensions.get('window');

export default function RateScreen() {
  const { theme, isDark } = useTheme();
  const { user, profile, refreshProfile } = useAuth();
  const searchParams = useLocalSearchParams();
  const [pics, setPics] = useState<FeetPic[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [loading, setLoading] = useState(true);
  const [rating, setRating] = useState(0);
  const [submitting, setSubmitting] = useState(false);
  const [upgrading, setUpgrading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const fetchPicsToRate = async () => {
    if (!user) return;

    const { data: ratedPics } = await supabase
      .from('ratings')
      .select('pic_id')
      .eq('rater_id', user.id);

    const ratedPicIds = ratedPics?.map((r) => r.pic_id) || [];

    let query = supabase
      .from('feet_pics')
      .select(
        `
        *,
        profiles:user_id (
          username
        )
      `
      )
      .neq('user_id', user.id);

    if (ratedPicIds.length > 0) {
      query = query.not('id', 'in', `(${ratedPicIds.join(',')})`);
    }

    const { data, error } = await query
      .order('created_at', { ascending: false })
      .limit(20);

    if (data) {
      setPics(data as any);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchPicsToRate();

    const channel = supabase
      .channel('feet_pics_changes')
      .on(
        'postgres_changes',
        { event: 'DELETE', schema: 'public', table: 'feet_pics' },
        () => {
          fetchPicsToRate();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user]);

  useEffect(() => {
    if (searchParams.success === 'true') {
      setSuccessMessage('Payment successful! Syncing your subscription...');
      setError(null);

      const syncAfterPayment = async () => {
        await new Promise(resolve => setTimeout(resolve, 2000));
        try {
          await refreshProfile();
          setSuccessMessage('Premium activated! You can now rate unlimited pics.');
          router.replace('/rate');
        } catch (error) {
          setError('Please refresh the page to see your premium status');
        }
      };

      syncAfterPayment();
    } else if (searchParams.canceled === 'true') {
      setError('Payment was canceled');
      setTimeout(() => {
        router.replace('/rate');
      }, 2000);
    }
  }, [searchParams]);

  const submitRating = async () => {
    if (!user || !profile || rating === 0) return;

    if (!profile.is_premium) {
      setError('You need to upgrade to premium to rate photos');
      return;
    }

    setSubmitting(true);
    setError(null);
    setSuccessMessage(null);

    try {
      const currentPic = pics[currentIndex];

      const { error: submitError } = await supabase.from('ratings').insert({
        pic_id: currentPic.id,
        rater_id: user.id,
        rating: rating,
      });

      if (submitError) throw submitError;

      setSuccessMessage(`Rating submitted: ${rating}/10`);
      setTimeout(() => setSuccessMessage(null), 2000);

      setRating(0);

      const newPics = pics.filter((_, index) => index !== currentIndex);
      setPics(newPics);

      if (currentIndex >= newPics.length && newPics.length > 0) {
        setCurrentIndex(newPics.length - 1);
      }
    } catch (error: any) {
      setError(error.message || 'Failed to submit rating');
    } finally {
      setSubmitting(false);
    }
  };

  const skipPic = () => {
    setRating(0);
    setCurrentIndex(currentIndex + 1);
  };

  const upgradeToPremium = async () => {
    if (!user) return;

    setUpgrading(true);
    setError(null);

    try {
      const priceId = process.env.EXPO_PUBLIC_STRIPE_PRICE_ID;
      if (!priceId || priceId === 'price_REPLACE_WITH_YOUR_PRICE_ID') {
        setError('Stripe is not configured. Please add EXPO_PUBLIC_STRIPE_PRICE_ID to .env');
        setUpgrading(false);
        return;
      }

      const publishableKey = process.env.EXPO_PUBLIC_STRIPE_PUBLISHABLE_KEY;
      if (!publishableKey || publishableKey === 'pk_test_REPLACE_WITH_YOUR_PUBLISHABLE_KEY') {
        setError('Stripe publishable key not configured');
        setUpgrading(false);
        return;
      }

      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        setError('Please sign in to upgrade');
        setUpgrading(false);
        return;
      }

      const apiUrl = `${process.env.EXPO_PUBLIC_SUPABASE_URL}/functions/v1/stripe-checkout`;
      const baseUrl = typeof window !== 'undefined' ? window.location.origin : '';

      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          price_id: priceId,
          success_url: `${baseUrl}/rate?success=true`,
          cancel_url: `${baseUrl}/rate?canceled=true`,
          mode: 'subscription'
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        console.error('Payment sheet error:', errorData);
        throw new Error(errorData.error || 'Failed to prepare payment');
      }

      const { url } = await response.json();

      if (url) {
        if (typeof window !== 'undefined') {
          window.open(url, '_blank');
        }
        setSuccessMessage('Redirecting to checkout...');
      } else {
        throw new Error('No checkout URL received');
      }
      setTimeout(() => {
        setSuccessMessage(null);
      }, 3000);
    } catch (error: any) {
      console.error('Upgrade error:', error);
      setError(error.message || 'Failed to start payment');
    } finally {
      setUpgrading(false);
    }
  };

  if (loading) {
    return (
      <View style={[styles.loadingContainer, { backgroundColor: theme.background }]}>
        <ActivityIndicator size="large" color={theme.primary} />
      </View>
    );
  }

  if (!profile?.is_premium) {
    return (
      <View style={[styles.container, { backgroundColor: theme.background }]}>
        <View style={styles.headerWrapper}>
          <View style={[styles.header, { backgroundColor: isDark ? 'rgba(26, 22, 53, 0.95)' : 'rgba(243, 241, 255, 0.98)', borderColor: isDark ? 'transparent' : 'rgba(139, 92, 246, 0.2)' }]}>
            <View style={styles.headerLeft}>
              <View style={[styles.iconWrapper, { backgroundColor: '#34c759' + '20' }]}>
                <ThumbsUp size={26} color="#34c759" strokeWidth={2.5} />
              </View>
              <Text style={[styles.title, { color: theme.text }]}>Rate</Text>
            </View>
          </View>
        </View>

        {error && (
          <View style={styles.errorBanner}>
            <Text style={styles.errorText}>{error}</Text>
            <TouchableOpacity onPress={() => setError(null)}>
              <Text style={styles.dismissText}>✕</Text>
            </TouchableOpacity>
          </View>
        )}

        {successMessage && (
          <View style={styles.successBanner}>
            <Text style={styles.successText}>{successMessage}</Text>
          </View>
        )}

        <View style={styles.premiumContainer}>
          <Crown size={64} color="#ffd700" fill="#ffd700" />
          <Text style={styles.premiumTitle}>Premium Feature</Text>
          <Text style={styles.premiumText}>
            Upgrade to premium to rate photos and match with others who rate you
            highly
          </Text>
          <TouchableOpacity
            style={[styles.upgradeButton, upgrading && styles.upgradeButtonDisabled]}
            onPress={upgradeToPremium}
            disabled={upgrading}
          >
            {upgrading ? (
              <ActivityIndicator color="#000" />
            ) : (
              <Text style={styles.upgradeButtonText}>Upgrade to Premium</Text>
            )}
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  if (currentIndex >= pics.length) {
    return (
      <View style={[styles.container, { backgroundColor: theme.background }]}>
        <View style={styles.headerWrapper}>
          <View style={[styles.header, { backgroundColor: isDark ? 'rgba(26, 22, 53, 0.95)' : 'rgba(243, 241, 255, 0.98)', borderColor: isDark ? 'transparent' : 'rgba(139, 92, 246, 0.2)' }]}>
            <View style={styles.headerLeft}>
              <View style={[styles.iconWrapper, { backgroundColor: '#34c759' + '20' }]}>
                <ThumbsUp size={26} color="#34c759" strokeWidth={2.5} />
              </View>
              <Text style={[styles.title, { color: theme.text }]}>Rate</Text>
            </View>
          </View>
        </View>
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyText}>No more pics to rate</Text>
          <Text style={styles.emptySubtext}>Check back later for more</Text>
          <TouchableOpacity
            style={styles.refreshButton}
            onPress={() => {
              setCurrentIndex(0);
              fetchPicsToRate();
            }}
          >
            <Text style={styles.refreshButtonText}>Refresh</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  const currentPic = pics[currentIndex];

  return (
    <View style={[styles.container, { backgroundColor: theme.background }]}>
      <View style={styles.headerWrapper}>
        <View style={[styles.header, { backgroundColor: isDark ? 'rgba(26, 22, 53, 0.95)' : 'rgba(243, 241, 255, 0.98)', borderColor: isDark ? 'transparent' : 'rgba(139, 92, 246, 0.2)' }]}>
          <View style={styles.headerLeft}>
            <View style={[styles.iconWrapper, { backgroundColor: '#34c759' + '20' }]}>
              <ThumbsUp size={26} color="#34c759" strokeWidth={2.5} />
            </View>
            <Text style={[styles.title, { color: theme.text }]}>Rate</Text>
          </View>
          <Text style={[styles.counter, { color: theme.textTertiary }]}>
            {currentIndex + 1} / {pics.length}
          </Text>
        </View>
      </View>

      {error && (
        <View style={styles.errorBanner}>
          <Text style={styles.errorText}>{error}</Text>
          <TouchableOpacity onPress={() => setError(null)}>
            <Text style={styles.dismissText}>✕</Text>
          </TouchableOpacity>
        </View>
      )}

      {successMessage && (
        <View style={styles.successBanner}>
          <Text style={styles.successText}>{successMessage}</Text>
        </View>
      )}

      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
      <View style={styles.cardContainer}>
        <View style={styles.card}>
          <Image
            source={{ uri: currentPic.image_url }}
            style={styles.image}
            resizeMode="cover"
          />
          <View style={styles.infoOverlay}>
            <Text style={styles.username}>@{currentPic.profiles?.username || 'Anonymous'}</Text>
            <View style={styles.aiRatingBadge}>
              <Star size={16} color="#ffd700" fill="#ffd700" />
              <Text style={styles.aiRatingText}>
                AI: {currentPic.ai_rating?.toFixed(1) || 'N/A'}
              </Text>
            </View>
          </View>
        </View>
      </View>

      <View style={styles.ratingContainer}>
        <Text style={styles.ratingLabel}>Your Rating</Text>
        <View style={styles.starsContainer}>
          {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((star) => (
            <TouchableOpacity
              key={star}
              style={[
                styles.starButton,
                rating >= star && styles.starButtonActive,
              ]}
              onPress={() => setRating(star)}
            >
              <Text
                style={[
                  styles.starNumber,
                  rating >= star && styles.starNumberActive,
                ]}
              >
                {star}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      <View style={styles.actionsContainer}>
        <TouchableOpacity style={styles.skipButton} onPress={skipPic}>
          <X size={24} color="#fff" />
          <Text style={styles.skipButtonText}>Skip</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[
            styles.submitButton,
            (rating === 0 || submitting) && styles.submitButtonDisabled,
          ]}
          onPress={submitRating}
          disabled={rating === 0 || submitting}
        >
          {submitting ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <Text style={styles.submitButtonText}>Submit Rating</Text>
          )}
        </TouchableOpacity>
      </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  scrollContent: {
    paddingBottom: 120,
  },
  headerWrapper: {
    paddingTop: 50,
    paddingHorizontal: 16,
    paddingBottom: 16,
  },
  header: {
    borderRadius: 20,
    padding: 20,
    borderWidth: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 12,
    elevation: 5,
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
  },
  iconWrapper: {
    width: 52,
    height: 52,
    borderRadius: 26,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    letterSpacing: -0.5,
    color: '#fff',
  },
  counter: {
    fontSize: 14,
    color: '#888',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#000',
  },
  premiumContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 32,
  },
  premiumTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#fff',
    marginTop: 24,
    marginBottom: 12,
  },
  premiumText: {
    fontSize: 16,
    color: '#888',
    textAlign: 'center',
    lineHeight: 24,
    marginBottom: 32,
  },
  upgradeButton: {
    backgroundColor: '#ffd700',
    borderRadius: 12,
    paddingVertical: 16,
    paddingHorizontal: 32,
  },
  upgradeButtonDisabled: {
    opacity: 0.6,
  },
  upgradeButtonText: {
    color: '#000',
    fontSize: 16,
    fontWeight: '700',
  },
  cardContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
  },
  card: {
    width: width - 32,
    height: height * 0.5,
    borderRadius: 24,
    overflow: 'hidden',
    backgroundColor: '#1a1a1a',
  },
  image: {
    width: '100%',
    height: '100%',
  },
  infoOverlay: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    padding: 20,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  username: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '600',
  },
  aiRatingBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 215, 0, 0.2)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
    gap: 6,
  },
  aiRatingText: {
    color: '#ffd700',
    fontSize: 14,
    fontWeight: '600',
  },
  ratingContainer: {
    padding: 16,
    backgroundColor: '#1a1a1a',
    borderTopWidth: 1,
    borderTopColor: '#333',
  },
  ratingLabel: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 12,
    textAlign: 'center',
  },
  starsContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 8,
  },
  starButton: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#333',
    justifyContent: 'center',
    alignItems: 'center',
  },
  starButtonActive: {
    backgroundColor: '#ffd700',
  },
  starNumber: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
  },
  starNumberActive: {
    color: '#000',
  },
  actionsContainer: {
    flexDirection: 'row',
    padding: 16,
    gap: 12,
  },
  skipButton: {
    flex: 1,
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
    borderWidth: 1,
    borderColor: '#333',
  },
  skipButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  submitButton: {
    flex: 2,
    backgroundColor: '#0066ff',
    borderRadius: 12,
    padding: 16,
    justifyContent: 'center',
    alignItems: 'center',
  },
  submitButtonDisabled: {
    opacity: 0.5,
  },
  submitButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 32,
  },
  emptyText: {
    color: '#fff',
    fontSize: 20,
    fontWeight: '600',
    marginBottom: 8,
  },
  emptySubtext: {
    color: '#666',
    fontSize: 14,
    marginBottom: 32,
  },
  refreshButton: {
    backgroundColor: '#0066ff',
    borderRadius: 12,
    paddingVertical: 12,
    paddingHorizontal: 24,
  },
  refreshButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  errorBanner: {
    backgroundColor: '#ff3b30',
    paddingVertical: 12,
    paddingHorizontal: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderBottomWidth: 1,
    borderBottomColor: '#cc2e24',
  },
  errorText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
    flex: 1,
    marginRight: 12,
  },
  dismissText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
    paddingHorizontal: 8,
  },
  successBanner: {
    backgroundColor: '#34c759',
    paddingVertical: 12,
    paddingHorizontal: 16,
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#2aa347',
  },
  successText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
  },
});
