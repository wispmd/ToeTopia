import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Image,
  ActivityIndicator,
  Alert,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { useAuth } from '@/contexts/AuthContext';
import { useTheme } from '@/contexts/ThemeContext';
import { supabase } from '@/lib/supabase';
import {
  User as UserIcon,
  LogOut,
  Crown,
  ImageIcon,
  Star,
  Heart,
  Trash2,
  Camera,
  Moon,
  Sun,
  Settings,
} from 'lucide-react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { Platform } from 'react-native';

interface Stats {
  totalPics: number;
  averageAiRating: number;
  averageHumanRating: number;
  totalRatings: number;
}

interface FeetPic {
  id: string;
  image_url: string;
  ai_rating: number;
  human_rating_avg: number | null;
  human_rating_count: number;
  created_at: string;
}

export default function ProfileScreen() {
  const { user, profile, signOut, refreshProfile } = useAuth();
  const searchParams = useLocalSearchParams();
  const [stats, setStats] = useState<Stats>({
    totalPics: 0,
    averageAiRating: 0,
    averageHumanRating: 0,
    totalRatings: 0,
  });
  const [myPics, setMyPics] = useState<FeetPic[]>([]);
  const [loading, setLoading] = useState(true);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [uploadingAvatar, setUploadingAvatar] = useState(false);
  const [signOutConfirm, setSignOutConfirm] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [cancelAtPeriodEnd, setCancelAtPeriodEnd] = useState(false);
  const { theme, isDark, themeMode, setThemeMode } = useTheme();

  const fetchStats = async () => {
    if (!user) return;

    const { data: pics } = await supabase
      .from('feet_pics')
      .select('id, image_url, ai_rating, human_rating_avg, human_rating_count, created_at')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    if (pics) {
      setMyPics(pics);
      const totalPics = pics.length;
      const avgAi =
        pics.reduce((sum, pic) => sum + Number(pic.ai_rating), 0) /
        (totalPics || 1);
      const picsWithHumanRatings = pics.filter(
        (p) => p.human_rating_avg !== null
      );
      const avgHuman =
        picsWithHumanRatings.reduce(
          (sum, pic) => sum + Number(pic.human_rating_avg),
          0
        ) / (picsWithHumanRatings.length || 1);
      const totalRatings = pics.reduce(
        (sum, pic) => sum + Number(pic.human_rating_count),
        0
      );

      setStats({
        totalPics,
        averageAiRating: avgAi,
        averageHumanRating: avgHuman,
        totalRatings,
      });
    }

    if (profile?.is_premium) {
      const { data: customerData } = await supabase
        .from('stripe_customers')
        .select('customer_id')
        .eq('user_id', user.id)
        .maybeSingle();

      if (customerData?.customer_id) {
        const { data: subscriptionData } = await supabase
          .from('stripe_subscriptions')
          .select('cancel_at_period_end')
          .eq('customer_id', customerData.customer_id)
          .maybeSingle();

        if (subscriptionData) {
          setCancelAtPeriodEnd(subscriptionData.cancel_at_period_end || false);
        }
      }
    }

    setLoading(false);
  };

  useEffect(() => {
    fetchStats();
  }, [user]);

  useEffect(() => {
    if (searchParams.success === 'true') {
      setMessage({ type: 'success', text: 'Payment successful! Syncing your subscription...' });

      const syncAfterPayment = async () => {
        await new Promise(resolve => setTimeout(resolve, 2000));
        try {
          await refreshProfile();
          await fetchStats();
          setMessage({ type: 'success', text: 'Premium activated!' });
          router.replace('/profile');
        } catch (error) {
          setMessage({ type: 'error', text: 'Please refresh the page to see your premium status' });
        }
      };

      syncAfterPayment();
    } else if (searchParams.canceled === 'true') {
      setMessage({ type: 'error', text: 'Payment was canceled' });
      setTimeout(() => {
        router.replace('/profile');
      }, 2000);
    }
  }, [searchParams]);

  const handleSignOut = async () => {
    await signOut();
    router.replace('/(auth)');
  };

  const deletePic = async (picId: string, imageUrl: string) => {
    setDeleting(true);
    setMessage(null);
    try {
      const fileName = imageUrl.split('/').pop();
      if (fileName) {
        await supabase.storage.from('images').remove([`feet-pics/${fileName}`]);
      }

      const { error } = await supabase
        .from('feet_pics')
        .delete()
        .eq('id', picId);

      if (error) throw error;

      await fetchStats();
      setMessage({ type: 'success', text: 'Photo deleted successfully' });
      setDeleteConfirm(null);
    } catch (error: any) {
      setMessage({ type: 'error', text: error.message || 'Failed to delete photo' });
    } finally {
      setDeleting(false);
    }
  };

  const changeProfilePicture = async () => {
    if (!user) return;

    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') {
      setMessage({ type: 'error', text: 'Permission to access photos is required' });
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.8,
    });

    if (result.canceled || !result.assets[0]) return;

    setUploadingAvatar(true);
    setMessage(null);

    try {
      const response = await fetch(result.assets[0].uri);
      const blob = await response.blob();
      const fileName = `avatar-${user.id}-${Date.now()}.jpg`;
      const filePath = `avatars/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('images')
        .upload(filePath, blob, {
          contentType: 'image/jpeg',
          upsert: true,
        });

      if (uploadError) throw uploadError;

      const { data: publicUrlData } = supabase.storage
        .from('images')
        .getPublicUrl(filePath);

      const publicUrl = publicUrlData.publicUrl;

      const { error: updateError } = await supabase
        .from('profiles')
        .update({ avatar_url: publicUrl })
        .eq('id', user.id);

      if (updateError) throw updateError;

      await refreshProfile();
      setMessage({ type: 'success', text: 'Profile picture updated successfully' });
    } catch (error: any) {
      setMessage({ type: 'error', text: error.message || 'Failed to update profile picture' });
    } finally {
      setUploadingAvatar(false);
    }
  };

  const syncSubscription = async () => {
    if (!user) return;

    try {
      setMessage(null);
      const apiUrl = `${process.env.EXPO_PUBLIC_SUPABASE_URL}/functions/v1/sync-stripe-subscription`;

      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        setMessage({ type: 'error', text: 'Please sign in to sync' });
        return;
      }

      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to sync subscription');
      }

      setMessage({ type: 'success', text: 'Subscription synced! Refreshing...' });
      setTimeout(async () => {
        await refreshProfile();
        await fetchStats();
        setMessage({ type: 'success', text: 'Profile updated!' });
      }, 1000);
    } catch (error: any) {
      console.error('Sync error:', error);
      setMessage({ type: 'error', text: error.message || 'Failed to sync subscription' });
    }
  };

  const cancelSubscription = async () => {
    if (!user) return;

    try {
      setMessage(null);

      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        setMessage({ type: 'error', text: 'Please sign in' });
        return;
      }

      const apiUrl = `${process.env.EXPO_PUBLIC_SUPABASE_URL}/functions/v1/cancel-subscription`;

      console.log('Calling cancel-subscription API...');
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json',
        },
      });

      const responseText = await response.text();
      console.log('Cancel response:', responseText);

      if (!response.ok) {
        let errorMessage = 'Failed to cancel subscription';
        try {
          const error = JSON.parse(responseText);
          errorMessage = error.error || errorMessage;
        } catch (e) {
          errorMessage = responseText || errorMessage;
        }
        throw new Error(errorMessage);
      }

      const data = JSON.parse(responseText);
      console.log('Cancel successful:', data);

      setCancelAtPeriodEnd(true);
      await fetchStats();

      const expiryDate = data.expires_at
        ? new Date(data.expires_at).toLocaleDateString()
        : profile?.subscription_expires_at
        ? new Date(profile.subscription_expires_at).toLocaleDateString()
        : 'the end of your billing period';

      setMessage({
        type: 'success',
        text: `Subscription canceled. You'll retain premium access until ${expiryDate}`
      });
    } catch (error: any) {
      console.error('Cancel error:', error);
      setMessage({ type: 'error', text: error.message || 'Failed to cancel subscription' });
    }
  };

  const togglePremium = async () => {
    if (!user) return;

    if (profile?.is_premium) {
      if (Platform.OS === 'web') {
        if (confirm('Are you sure you want to cancel your subscription? You will retain access until the end of your billing period.')) {
          await cancelSubscription();
        }
      } else {
        Alert.alert(
          'Cancel Subscription',
          'Are you sure you want to cancel your subscription? You will retain access until the end of your billing period.',
          [
            { text: 'No', style: 'cancel' },
            { text: 'Yes', onPress: cancelSubscription },
          ]
        );
      }
      return;
    }

    try {
      setMessage(null);

      const priceId = process.env.EXPO_PUBLIC_STRIPE_PRICE_ID;
      if (!priceId || priceId === 'price_REPLACE_WITH_YOUR_PRICE_ID') {
        setMessage({ type: 'error', text: 'Stripe is not configured. Please add EXPO_PUBLIC_STRIPE_PRICE_ID to .env' });
        return;
      }

      const publishableKey = process.env.EXPO_PUBLIC_STRIPE_PUBLISHABLE_KEY;
      if (!publishableKey || publishableKey === 'pk_test_REPLACE_WITH_YOUR_PUBLISHABLE_KEY') {
        setMessage({ type: 'error', text: 'Stripe publishable key not configured' });
        return;
      }

      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        setMessage({ type: 'error', text: 'Please sign in to upgrade' });
        return;
      }

      setMessage({ type: 'success', text: 'Preparing payment...' });

      const apiUrl = `${process.env.EXPO_PUBLIC_SUPABASE_URL}/functions/v1/stripe-checkout`;
      const baseUrl = typeof window !== 'undefined' ? window.location.origin : '';

      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          price_id: priceId,
          success_url: `${baseUrl}/profile?success=true`,
          cancel_url: `${baseUrl}/profile?canceled=true`,
          mode: 'subscription'
        }),
      });

      if (!response.ok) {
        const error = await response.json();
        console.error('Checkout error:', error);
        throw new Error(error.error || 'Failed to prepare payment');
      }

      const { url } = await response.json();

      if (url) {
        if (typeof window !== 'undefined') {
          window.open(url, '_blank');
        }
        setMessage({ type: 'success', text: 'Redirecting to checkout...' });
      } else {
        throw new Error('No checkout URL received');
      }

      setTimeout(() => {
        setMessage(null);
      }, 2000);
    } catch (error: any) {
      console.error('Upgrade error:', error);
      setMessage({ type: 'error', text: error.message || 'Failed to start payment' });
    }
  };

  if (loading) {
    return (
      <View style={[styles.loadingContainer, { backgroundColor: theme.background }]}>
        <ActivityIndicator size="large" color={theme.primary} />
      </View>
    );
  }

  const toggleTheme = () => {
    if (themeMode === 'light') {
      setThemeMode('dark');
    } else if (themeMode === 'dark') {
      setThemeMode('light');
    } else {
      setThemeMode('light');
    }
  };

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: theme.background }]}
      contentContainerStyle={styles.scrollContent}
    >
      <View style={styles.headerWrapper}>
        <View style={[styles.header, { backgroundColor: isDark ? 'rgba(26, 22, 53, 0.95)' : 'rgba(243, 241, 255, 0.98)', borderColor: isDark ? 'transparent' : 'rgba(139, 92, 246, 0.2)' }]}>
          <View style={styles.headerLeft}>
            <View style={[styles.iconWrapper, { backgroundColor: theme.primary + '20' }]}>
              <UserIcon size={26} color={theme.primary} strokeWidth={2.5} />
            </View>
            <Text style={[styles.title, { color: theme.text }]}>Profile</Text>
          </View>
          <TouchableOpacity
            style={[styles.themeToggle, { backgroundColor: theme.surface, borderColor: theme.border }]}
            onPress={toggleTheme}
          >
            {isDark ? (
              <Sun size={22} color={theme.primary} />
            ) : (
              <Moon size={22} color={theme.primary} />
            )}
          </TouchableOpacity>
        </View>
      </View>

      {message && (
        <View style={[styles.messageBanner, message.type === 'error' ? styles.errorBanner : styles.successBanner]}>
          <Text style={styles.messageText}>{message.text}</Text>
          <TouchableOpacity onPress={() => setMessage(null)}>
            <Text style={styles.dismissText}>✕</Text>
          </TouchableOpacity>
        </View>
      )}

      <View style={[styles.profileSection, { borderBottomColor: theme.border }]}>
        <View style={styles.avatarContainer}>
          {profile?.avatar_url ? (
            <Image source={{ uri: profile.avatar_url }} style={styles.avatar} />
          ) : (
            <View style={[styles.avatarPlaceholder, { backgroundColor: theme.tertiaryBackground }]}>
              <UserIcon size={48} color={theme.textTertiary} />
            </View>
          )}
          <TouchableOpacity
            style={[styles.changeAvatarButton, { backgroundColor: theme.primary }]}
            onPress={changeProfilePicture}
            disabled={uploadingAvatar}
          >
            {uploadingAvatar ? (
              <ActivityIndicator size="small" color="#fff" />
            ) : (
              <Camera size={20} color="#fff" />
            )}
          </TouchableOpacity>
        </View>

        <Text style={[styles.username, { color: theme.text }]}>{profile?.username}</Text>
        <Text style={[styles.email, { color: theme.textSecondary }]}>{user?.email}</Text>

        {profile?.is_premium && (
          <View style={[styles.premiumBadge, { backgroundColor: theme.warning }]}>
            <Crown size={16} color="#000" />
            <Text style={styles.premiumBadgeText}>Premium Member</Text>
          </View>
        )}
      </View>

      <View style={styles.statsSection}>
        <Text style={[styles.sectionTitle, { color: theme.text }]}>Your Stats</Text>

        <View style={styles.statsGrid}>
          <View style={[styles.statCard, { backgroundColor: theme.surface, borderColor: theme.border }]}>
            <ImageIcon size={32} color={theme.primary} />
            <Text style={[styles.statValue, { color: theme.text }]}>{stats.totalPics}</Text>
            <Text style={[styles.statLabel, { color: theme.textTertiary }]}>Pics Uploaded</Text>
          </View>

          <View style={[styles.statCard, { backgroundColor: theme.surface, borderColor: theme.border }]}>
            <Star size={32} color="#ffd700" />
            <Text style={[styles.statValue, { color: theme.text }]}>
              {stats.averageAiRating.toFixed(1)}
            </Text>
            <Text style={[styles.statLabel, { color: theme.textTertiary }]}>Avg AI Rating</Text>
          </View>

          <View style={[styles.statCard, { backgroundColor: theme.surface, borderColor: theme.border }]}>
            <Heart size={32} color={theme.secondary} />
            <Text style={[styles.statValue, { color: theme.text }]}>
              {stats.averageHumanRating.toFixed(1)}
            </Text>
            <Text style={[styles.statLabel, { color: theme.textTertiary }]}>Avg Human Rating</Text>
          </View>

          <View style={[styles.statCard, { backgroundColor: theme.surface, borderColor: theme.border }]}>
            <UserIcon size={32} color={theme.primary} />
            <Text style={[styles.statValue, { color: theme.text }]}>{stats.totalRatings}</Text>
            <Text style={[styles.statLabel, { color: theme.textTertiary }]}>Total Ratings</Text>
          </View>
        </View>
      </View>

      {myPics.length > 0 && (
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>My Photos</Text>
          <View style={styles.photosGrid}>
            {myPics.map((pic) => (
              <View key={pic.id} style={styles.photoCard}>
                <Image source={{ uri: pic.image_url }} style={styles.photo} />
                <View style={styles.photoOverlay}>
                  <View style={styles.photoRatings}>
                    <View style={styles.ratingBadge}>
                      <Star size={12} color="#ffd700" fill="#ffd700" />
                      <Text style={styles.ratingText}>{pic.ai_rating.toFixed(1)}</Text>
                    </View>
                    {pic.human_rating_avg && (
                      <View style={styles.ratingBadge}>
                        <Heart size={12} color="#ff3b30" fill="#ff3b30" />
                        <Text style={styles.ratingText}>
                          {pic.human_rating_avg.toFixed(1)}
                        </Text>
                      </View>
                    )}
                  </View>
                  {deleteConfirm === pic.id ? (
                    <View style={styles.confirmDelete}>
                      <TouchableOpacity
                        style={styles.confirmButton}
                        onPress={() => deletePic(pic.id, pic.image_url)}
                        disabled={deleting}
                      >
                        <Text style={styles.confirmButtonText}>
                          {deleting ? '...' : 'Delete'}
                        </Text>
                      </TouchableOpacity>
                      <TouchableOpacity
                        style={styles.deleteCancelButton}
                        onPress={() => setDeleteConfirm(null)}
                      >
                        <Text style={styles.deleteCancelButtonText}>Cancel</Text>
                      </TouchableOpacity>
                    </View>
                  ) : (
                    <TouchableOpacity
                      style={styles.deleteButton}
                      onPress={() => setDeleteConfirm(pic.id)}
                    >
                      <Trash2 size={18} color="#ff3b30" />
                    </TouchableOpacity>
                  )}
                </View>
              </View>
            ))}
          </View>
        </View>
      )}

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Membership</Text>

        {profile?.is_premium ? (
          <View style={styles.premiumCard}>
            <View style={styles.premiumCardHeader}>
              <Crown size={32} color="#ffd700" />
              <Text style={styles.premiumCardTitle}>Premium Member</Text>
            </View>
            <Text style={styles.premiumCardText}>
              You have access to all premium features including rating others'
              photos and matching with high raters.
            </Text>
            {cancelAtPeriodEnd && profile?.subscription_expires_at && (
              <View style={[styles.cancelNotice, { backgroundColor: theme.border }]}>
                <Text style={[styles.cancelNoticeText, { color: theme.text }]}>
                  Your subscription will end on{' '}
                  {new Date(profile.subscription_expires_at).toLocaleDateString()}.
                  You'll retain premium access until then.
                </Text>
              </View>
            )}
            {!cancelAtPeriodEnd && (
              <TouchableOpacity
                style={styles.cancelButton}
                onPress={togglePremium}
              >
                <Text style={styles.cancelButtonText}>Cancel Subscription</Text>
              </TouchableOpacity>
            )}
          </View>
        ) : (
          <View style={styles.upgradeCard}>
            <Crown size={48} color="#ffd700" />
            <Text style={styles.upgradeTitle}>Upgrade to Premium</Text>
            <Text style={styles.upgradeText}>
              Get access to exclusive features:{'\n\n'}
              • Rate other users' photos{'\n'}
              • Match with users who rate you highly{'\n'}
              • Chat with your matches{'\n'}
              • Priority support
            </Text>
            <TouchableOpacity
              style={styles.upgradeButton}
              onPress={togglePremium}
            >
              <Text style={styles.upgradeButtonText}>
                Upgrade Now
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.upgradeButton, { backgroundColor: theme.border, marginTop: 12 }]}
              onPress={syncSubscription}
            >
              <Text style={styles.upgradeButtonText}>
                Already Paid? Sync Subscription
              </Text>
            </TouchableOpacity>
          </View>
        )}
      </View>

      <View style={styles.section}>
        <TouchableOpacity
          style={[styles.actionButton, { backgroundColor: theme.surface, borderColor: theme.border }]}
          onPress={() => router.push('/(tabs)/preferences')}
        >
          <Settings size={20} color={theme.primary} />
          <Text style={[styles.actionButtonText, { color: theme.text }]}>Preferences</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.signOutButton} onPress={handleSignOut}>
          <LogOut size={20} color="#ff3b30" />
          <Text style={styles.signOutText}>Sign Out</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContent: {
    paddingBottom: 120,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerWrapper: {
    paddingTop: 50,
    paddingHorizontal: 16,
    paddingBottom: 16,
  },
  header: {
    borderRadius: 20,
    padding: 20,
    borderWidth: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 12,
    elevation: 5,
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
  },
  iconWrapper: {
    width: 52,
    height: 52,
    borderRadius: 26,
    alignItems: 'center',
    justifyContent: 'center',
  },
  themeToggle: {
    width: 44,
    height: 44,
    borderRadius: 22,
    borderWidth: 2,
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#fff',
    letterSpacing: -0.5,
  },
  profileSection: {
    alignItems: 'center',
    padding: 32,
    borderBottomWidth: 1,
    borderBottomColor: '#1a1a1a',
  },
  avatarContainer: {
    position: 'relative',
    marginBottom: 16,
  },
  avatar: {
    width: 100,
    height: 100,
    borderRadius: 50,
  },
  avatarPlaceholder: {
    width: 100,
    height: 100,
    borderRadius: 50,
    justifyContent: 'center',
    alignItems: 'center',
  },
  changeAvatarButton: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 3,
    borderColor: 'transparent',
  },
  username: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 4,
  },
  email: {
    fontSize: 14,
    color: '#888',
  },
  premiumBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    marginTop: 12,
    gap: 6,
  },
  premiumBadgeText: {
    color: '#000',
    fontWeight: '700',
    fontSize: 12,
  },
  statsSection: {
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#1a1a1a',
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#fff',
    marginBottom: 16,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  statCard: {
    flex: 1,
    minWidth: '47%',
    borderRadius: 16,
    padding: 20,
    alignItems: 'center',
    borderWidth: 1,
  },
  statValue: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#fff',
    marginTop: 12,
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    color: '#888',
    textAlign: 'center',
  },
  section: {
    padding: 16,
  },
  premiumCard: {
    backgroundColor: '#1a1a1a',
    borderRadius: 16,
    padding: 24,
    borderWidth: 2,
    borderColor: '#ffd700',
  },
  premiumCardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 12,
  },
  premiumCardTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#fff',
  },
  premiumCardText: {
    fontSize: 14,
    color: '#888',
    lineHeight: 22,
    marginBottom: 20,
  },
  cancelButton: {
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    padding: 14,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#ff3b30',
  },
  cancelButtonText: {
    color: '#ff3b30',
    fontSize: 14,
    fontWeight: '600',
  },
  cancelNotice: {
    borderRadius: 12,
    padding: 16,
    marginTop: 12,
  },
  cancelNoticeText: {
    fontSize: 14,
    lineHeight: 20,
    textAlign: 'center',
  },
  upgradeCard: {
    backgroundColor: '#1a1a1a',
    borderRadius: 16,
    padding: 24,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#333',
  },
  upgradeTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
    marginTop: 16,
    marginBottom: 12,
  },
  upgradeText: {
    fontSize: 14,
    color: '#888',
    lineHeight: 24,
    marginBottom: 24,
  },
  upgradeButton: {
    backgroundColor: '#ffd700',
    borderRadius: 12,
    paddingVertical: 14,
    paddingHorizontal: 32,
  },
  upgradeButtonText: {
    color: '#000',
    fontSize: 16,
    fontWeight: '700',
  },
  actionButton: {
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    borderWidth: 1,
    marginBottom: 12,
  },
  actionButtonText: {
    fontSize: 16,
    fontWeight: '600',
  },
  signOutButton: {
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    borderWidth: 1,
    borderColor: '#333',
  },
  signOutText: {
    color: '#ff3b30',
    fontSize: 16,
    fontWeight: '600',
  },
  photosGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  photoCard: {
    width: '48%',
    aspectRatio: 1,
    borderRadius: 12,
    overflow: 'hidden',
    backgroundColor: '#1a1a1a',
    position: 'relative',
  },
  photo: {
    width: '100%',
    height: '100%',
  },
  photoOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0,0,0,0.3)',
    padding: 8,
    justifyContent: 'space-between',
  },
  photoRatings: {
    flexDirection: 'row',
    gap: 6,
  },
  ratingBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.6)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    gap: 4,
  },
  ratingText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '700',
  },
  deleteButton: {
    alignSelf: 'flex-end',
    backgroundColor: 'rgba(0,0,0,0.6)',
    padding: 8,
    borderRadius: 20,
  },
  confirmDelete: {
    alignSelf: 'stretch',
    flexDirection: 'row',
    gap: 4,
  },
  confirmButton: {
    flex: 1,
    backgroundColor: '#ff3b30',
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 8,
    alignItems: 'center',
  },
  confirmButtonText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '700',
  },
  deleteCancelButton: {
    flex: 1,
    backgroundColor: 'rgba(255,255,255,0.2)',
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 8,
    alignItems: 'center',
  },
  deleteCancelButtonText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '700',
  },
  messageBanner: {
    paddingVertical: 16,
    paddingHorizontal: 16,
    borderBottomWidth: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  errorBanner: {
    backgroundColor: '#ff3b30',
    borderBottomColor: '#cc2e24',
  },
  successBanner: {
    backgroundColor: '#34c759',
    borderBottomColor: '#2aa347',
  },
  messageText: {
    color: '#fff',
    fontSize: 15,
    fontWeight: '600',
    flex: 1,
    marginRight: 12,
  },
  dismissText: {
    color: '#fff',
    fontSize: 20,
    fontWeight: 'bold',
    paddingHorizontal: 8,
  },
});
