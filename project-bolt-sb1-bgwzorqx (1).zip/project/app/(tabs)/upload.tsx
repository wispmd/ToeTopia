import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  ActivityIndicator,
  ScrollView,
  Platform,
} from 'react-native';
import { Camera, Image as ImageIcon, Upload as UploadIcon } from 'lucide-react-native';
import * as ImagePicker from 'expo-image-picker';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { useTheme } from '@/contexts/ThemeContext';

export default function UploadScreen() {
  const { theme, isDark } = useTheme();
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [uploadStatus, setUploadStatus] = useState<string>('');
  const { user, profile, loading: authLoading } = useAuth();

  const pickImage = async () => {
    setErrorMessage(null);
    setSuccessMessage(null);
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();

    if (status !== 'granted') {
      setErrorMessage('Please allow access to your photo library');
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.8,
    });

    if (!result.canceled && result.assets[0]) {
      setSelectedImage(result.assets[0].uri);
    }
  };

  const takePhoto = async () => {
    setErrorMessage(null);
    setSuccessMessage(null);
    if (Platform.OS === 'web') {
      setErrorMessage('Camera is not available on web');
      return;
    }

    const { status } = await ImagePicker.requestCameraPermissionsAsync();

    if (status !== 'granted') {
      setErrorMessage('Please allow access to your camera');
      return;
    }

    const result = await ImagePicker.launchCameraAsync({
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.8,
    });

    if (!result.canceled && result.assets[0]) {
      setSelectedImage(result.assets[0].uri);
    }
  };

  const uploadImage = async () => {
    setErrorMessage(null);
    setSuccessMessage(null);
    if (!selectedImage || !user || !profile) {
      setErrorMessage('Please select an image and ensure your profile is set up');
      return;
    }

    setUploading(true);
    setUploadStatus('Uploading image...');
    console.log('Starting upload for user:', user.id, 'profile:', profile);

    try {
      const response = await fetch(selectedImage);
      const blob = await response.blob();
      const fileExt = 'jpg';
      const fileName = `${user.id}-${Date.now()}.${fileExt}`;
      const filePath = `feet-pics/${fileName}`;

      console.log('Uploading to:', filePath);

      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('images')
        .upload(filePath, blob, {
          contentType: 'image/jpeg',
          upsert: false,
        });

      if (uploadError) {
        console.error('Storage upload error:', uploadError);
        throw new Error(`Storage error: ${uploadError.message}`);
      }

      console.log('Upload successful:', uploadData);

      const {
        data: { publicUrl },
      } = supabase.storage.from('images').getPublicUrl(filePath);

      console.log('Image URL:', publicUrl);

      setUploadStatus('AI is analyzing your image...');
      const apiUrl = `${process.env.EXPO_PUBLIC_SUPABASE_URL}/functions/v1/rate-feet-ai`;
      console.log('Calling AI rating API:', apiUrl);

      const ratingResponse = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ imageUrl: publicUrl }),
      });

      const ratingData = await ratingResponse.json();
      console.log('AI rating response:', ratingData);
      console.log('Response status:', ratingResponse.status);
      console.log('Response ok:', ratingResponse.ok);

      if (!ratingResponse.ok || ratingData.isFeet === false) {
        console.log('Non-feet image detected, deleting from storage');
        await supabase.storage.from('images').remove([filePath]);

        setUploading(false);
        setSelectedImage(null);

        const errorMsg = ratingData.error || 'This does not appear to be a picture of feet. Please upload a clear photo of feet.';
        console.log('Setting error message:', errorMsg);

        setErrorMessage(errorMsg);
        return;
      }

      setUploadStatus('Saving to your profile...');
      console.log('Inserting into database:', {
        user_id: user.id,
        image_url: publicUrl,
        ai_rating: ratingData.rating,
      });

      const { data: insertData, error: insertError } = await supabase
        .from('feet_pics')
        .insert({
          user_id: user.id,
          image_url: publicUrl,
          ai_rating: ratingData.rating,
        })
        .select()
        .single();

      if (insertError) {
        console.error('Database insert error:', insertError);
        throw new Error(`Database error: ${insertError.message}`);
      }

      console.log('Insert successful:', insertData);

      setSuccessMessage(`Success! Your pic has been uploaded with an AI rating of ${ratingData.rating.toFixed(1)}/10`);
      setSelectedImage(null);
    } catch (error: any) {
      console.error('Upload error:', error);
      setErrorMessage(error.message || 'Failed to upload image');
    } finally {
      setUploading(false);
      setUploadStatus('');
    }
  };

  return (
    <View style={[styles.container, { backgroundColor: theme.background }]}>
      <View style={styles.headerWrapper}>
        <View style={[styles.header, { backgroundColor: isDark ? 'rgba(26, 22, 53, 0.95)' : 'rgba(243, 241, 255, 0.98)', borderColor: isDark ? 'transparent' : 'rgba(139, 92, 246, 0.2)' }]}>
          <View style={styles.titleContent}>
            <View style={[styles.iconWrapper, { backgroundColor: theme.primary + '20' }]}>
              <UploadIcon size={26} color={theme.primary} strokeWidth={2.5} />
            </View>
            <View>
              <Text style={[styles.title, { color: theme.text }]}>Upload</Text>
              <Text style={[styles.subtitle, { color: theme.textSecondary }]}>Share your pics</Text>
            </View>
          </View>
        </View>
      </View>

      {authLoading && (
        <View style={styles.warningBanner}>
          <ActivityIndicator size="small" color={theme.primary} />
          <Text style={[styles.warningText, { color: theme.textSecondary }]}>
            Loading profile...
          </Text>
        </View>
      )}

      {errorMessage && (
        <View style={styles.errorBanner}>
          <Text style={styles.errorText}>{errorMessage}</Text>
          <TouchableOpacity onPress={() => setErrorMessage(null)}>
            <Text style={styles.dismissText}>✕</Text>
          </TouchableOpacity>
        </View>
      )}

      {successMessage && (
        <View style={styles.successBanner}>
          <Text style={styles.successText}>{successMessage}</Text>
          <TouchableOpacity onPress={() => setSuccessMessage(null)}>
            <Text style={styles.dismissText}>✕</Text>
          </TouchableOpacity>
        </View>
      )}

      {uploadStatus && (
        <View style={styles.statusBanner}>
          <ActivityIndicator color="#007AFF" size="small" />
          <Text style={styles.statusText}>{uploadStatus}</Text>
        </View>
      )}

      <ScrollView contentContainerStyle={styles.content}>
        {selectedImage ? (
          <View style={styles.previewContainer}>
            <Image source={{ uri: selectedImage }} style={styles.preview} />
            <View style={styles.buttonRow}>
              <TouchableOpacity
                style={[styles.button, styles.secondaryButton]}
                onPress={() => setSelectedImage(null)}
              >
                <Text style={styles.secondaryButtonText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.button, styles.primaryButton, uploading && styles.buttonDisabled]}
                onPress={uploadImage}
                disabled={uploading}
              >
                {uploading ? (
                  <ActivityIndicator color="#fff" />
                ) : (
                  <>
                    <UploadIcon size={20} color="#fff" />
                    <Text style={styles.primaryButtonText}>Upload</Text>
                  </>
                )}
              </TouchableOpacity>
            </View>
          </View>
        ) : (
          <View style={styles.selectContainer}>
            <TouchableOpacity style={styles.selectButton} onPress={takePhoto}>
              <Camera size={48} color="#0066ff" />
              <Text style={styles.selectButtonText}>Take Photo</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.selectButton} onPress={pickImage}>
              <ImageIcon size={48} color="#0066ff" />
              <Text style={styles.selectButtonText}>Choose from Gallery</Text>
            </TouchableOpacity>
          </View>
        )}

        <View style={styles.infoBox}>
          <Text style={styles.infoTitle}>How it works</Text>
          <Text style={styles.infoText}>
            1. Take or select a photo of your feet{'\n'}
            2. Our AI will rate it automatically{'\n'}
            3. Premium users can give human ratings{'\n'}
            4. Match with others who rate you highly
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  headerWrapper: {
    paddingTop: 50,
    paddingHorizontal: 16,
    paddingBottom: 16,
  },
  header: {
    borderRadius: 20,
    padding: 20,
    borderWidth: 1,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 12,
    elevation: 5,
  },
  titleContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
  },
  iconWrapper: {
    width: 52,
    height: 52,
    borderRadius: 26,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#fff',
    letterSpacing: -0.5,
    marginBottom: 2,
  },
  subtitle: {
    fontSize: 14,
    color: '#888',
    marginTop: 4,
  },
  content: {
    padding: 16,
    paddingBottom: 100,
  },
  selectContainer: {
    gap: 16,
    marginTop: 40,
  },
  selectButton: {
    backgroundColor: '#1a1a1a',
    borderRadius: 16,
    padding: 32,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#333',
  },
  selectButtonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '600',
    marginTop: 16,
  },
  previewContainer: {
    gap: 16,
  },
  preview: {
    width: '100%',
    aspectRatio: 1,
    borderRadius: 16,
    backgroundColor: '#1a1a1a',
  },
  buttonRow: {
    flexDirection: 'row',
    gap: 12,
  },
  button: {
    flex: 1,
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    gap: 8,
  },
  primaryButton: {
    backgroundColor: '#0066ff',
  },
  secondaryButton: {
    backgroundColor: '#1a1a1a',
    borderWidth: 1,
    borderColor: '#333',
  },
  primaryButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  secondaryButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  buttonDisabled: {
    opacity: 0.6,
  },
  infoBox: {
    backgroundColor: '#1a1a1a',
    borderRadius: 12,
    padding: 20,
    marginTop: 32,
    borderWidth: 1,
    borderColor: '#333',
  },
  infoTitle: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 12,
  },
  infoText: {
    color: '#888',
    fontSize: 14,
    lineHeight: 22,
  },
  warningBanner: {
    backgroundColor: '#ff9500',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#ff8000',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  warningText: {
    color: '#000',
    fontSize: 14,
    fontWeight: '600',
    textAlign: 'center',
  },
  errorBanner: {
    backgroundColor: '#ff3b30',
    paddingVertical: 16,
    paddingHorizontal: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#cc2e24',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  errorText: {
    color: '#fff',
    fontSize: 15,
    fontWeight: '600',
    flex: 1,
    marginRight: 12,
  },
  dismissText: {
    color: '#fff',
    fontSize: 20,
    fontWeight: 'bold',
    paddingHorizontal: 8,
  },
  successBanner: {
    backgroundColor: '#34c759',
    paddingVertical: 16,
    paddingHorizontal: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#2aa347',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  successText: {
    color: '#fff',
    fontSize: 15,
    fontWeight: '600',
    flex: 1,
    marginRight: 12,
  },
  statusBanner: {
    backgroundColor: '#1c1c1e',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#2c2c2e',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  statusText: {
    color: '#007AFF',
    fontSize: 14,
    fontWeight: '600',
  },
});
