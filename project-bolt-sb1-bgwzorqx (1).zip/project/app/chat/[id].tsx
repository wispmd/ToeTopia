import React, { useEffect, useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
  Image,
  Alert,
  Modal,
} from 'react-native';
import { useLocalSearchParams, router } from 'expo-router';
import * as ImagePicker from 'expo-image-picker';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { useTheme } from '@/contexts/ThemeContext';
import { ArrowLeft, Send, ImageIcon, Smile, X } from 'lucide-react-native';

const FEET_EMOJIS = ['🦶', '👣', '🧦', '👟', '👠', '🥿', '👞', '👡', '🩴', '👢', '💅', '🎨', '✨', '💖', '🔥', '😍', '🥰', '😘', '💯', '👌', '🤩', '😋', '🤤'];

function MessageItem({ message, isOwn, onImagePress }: { message: Message; isOwn: boolean; onImagePress: (url: string) => void }) {
  const { theme } = useTheme();
  const [imageUrl, setImageUrl] = useState<string>('');

  useEffect(() => {
    if (message.message_type === 'image' && message.image_path) {
      supabase.storage
        .from('chat-images')
        .createSignedUrl(message.image_path, 3600)
        .then(({ data }) => {
          if (data?.signedUrl) setImageUrl(data.signedUrl);
        });
    }
  }, [message]);

  if (message.message_type === 'image') {
    return (
      <View style={[styles.messageContainer, isOwn ? styles.ownMessage : styles.otherMessage]}>
        <View style={[styles.messageBubble, isOwn ? styles.ownBubble : styles.otherBubble]}>
          {imageUrl ? (
            <TouchableOpacity onPress={() => onImagePress(imageUrl)}>
              <Image source={{ uri: imageUrl }} style={styles.chatImage} />
            </TouchableOpacity>
          ) : (
            <View style={[styles.chatImage, { backgroundColor: theme.surface, justifyContent: 'center', alignItems: 'center' }]}>
              <ActivityIndicator color={theme.primary} />
            </View>
          )}
          <Text style={[styles.messageTime, isOwn ? styles.ownTime : styles.otherTime]}>
            {new Date(message.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </Text>
        </View>
      </View>
    );
  }

  return (
    <View style={[styles.messageContainer, isOwn ? styles.ownMessage : styles.otherMessage]}>
      <View style={[styles.messageBubble, isOwn ? styles.ownBubble : styles.otherBubble]}>
        <Text style={[styles.messageText, isOwn ? styles.ownText : styles.otherText]}>
          {message.content}
        </Text>
        <Text style={[styles.messageTime, isOwn ? styles.ownTime : styles.otherTime]}>
          {new Date(message.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </Text>
      </View>
    </View>
  );
}

interface Message {
  id: string;
  content: string;
  sender_id: string;
  created_at: string;
  read: boolean;
  message_type: 'text' | 'image' | 'system';
  image_url?: string;
  image_path?: string;
}

interface Match {
  id: string;
  other_user: {
    id: string;
    username: string;
  };
}

export default function ChatScreen() {
  const { theme } = useTheme();
  const { id } = useLocalSearchParams();
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [match, setMatch] = useState<Match | null>(null);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [expandedImage, setExpandedImage] = useState<string | null>(null);
  const { user, profile } = useAuth();
  const flatListRef = useRef<FlatList>(null);

  const fetchMatch = async () => {
    if (!user) return;

    const { data: matchData } = await supabase
      .from('matches')
      .select(`*, user1:user1_id (id, username), user2:user2_id (id, username)`)
      .eq('id', id)
      .single();

    if (matchData) {
      const otherUser = matchData.user1.id === user.id ? matchData.user2 : matchData.user1;
      setMatch({ id: matchData.id, other_user: otherUser });
    }
  };

  const fetchMessages = async () => {
    const { data } = await supabase
      .from('messages')
      .select('*')
      .eq('match_id', id)
      .order('created_at', { ascending: true });

    if (data) {
      setMessages(data);
      markMessagesAsRead();
    }
    setLoading(false);
  };

  const markMessagesAsRead = async () => {
    if (!user) return;
    await supabase
      .from('messages')
      .update({ read: true })
      .eq('match_id', id)
      .neq('sender_id', user.id)
      .eq('read', false);
  };

  useEffect(() => {
    fetchMatch();
    fetchMessages();

    const subscription = supabase
      .channel(`messages_${id}`)
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'messages',
        filter: `match_id=eq.${id}`,
      }, (payload) => {
        setMessages((current) => [...current, payload.new as Message]);
        markMessagesAsRead();
        setTimeout(() => flatListRef.current?.scrollToEnd({ animated: true }), 100);
      })
      .subscribe();

    return () => { subscription.unsubscribe(); };
  }, [id, user]);

  const sendMessage = async () => {
    if (!newMessage.trim() || !user || sending) return;

    setSending(true);
    try {
      await supabase.from('messages').insert({
        match_id: id as string,
        sender_id: user.id,
        content: newMessage.trim(),
        message_type: 'text',
      });
      setNewMessage('');
    } catch (error) {
      console.error('Failed to send message:', error);
    } finally {
      setSending(false);
    }
  };

  const pickImage = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permission needed', 'Please grant access to your photo library');
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 0.8,
      allowsEditing: true,
    });

    if (!result.canceled && result.assets[0]) {
      await uploadImage(result.assets[0].uri);
    }
  };

  const uploadImage = async (uri: string) => {
    if (!user) return;

    setUploading(true);
    try {
      const response = await fetch(uri);
      const blob = await response.blob();
      const fileExt = uri.split('.').pop();
      const timestamp = new Date().getTime();
      const fileName = `${user.id}/${timestamp}.${fileExt}`;

      const { error: uploadError } = await supabase.storage
        .from('chat-images')
        .upload(fileName, blob);

      if (uploadError) throw uploadError;

      await supabase.from('messages').insert({
        match_id: id as string,
        sender_id: user.id,
        content: 'Shared an image',
        message_type: 'image',
        image_path: fileName,
      });
    } catch (error) {
      console.error('Failed to upload image:', error);
      Alert.alert('Error', 'Failed to upload image');
    } finally {
      setUploading(false);
    }
  };


  const insertEmoji = (emoji: string) => {
    setNewMessage((prev) => prev + emoji);
    setShowEmojiPicker(false);
  };

  const renderMessage = ({ item }: { item: Message }) => (
    <MessageItem message={item} isOwn={item.sender_id === user?.id} onImagePress={setExpandedImage} />
  );

  if (loading) {
    return (
      <View style={[styles.loadingContainer, { backgroundColor: theme.background }]}>
        <ActivityIndicator size="large" color={theme.primary} />
      </View>
    );
  }

  return (
    <KeyboardAvoidingView
      style={[styles.container, { backgroundColor: theme.background }]}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      keyboardVerticalOffset={0}
    >
      <View style={[styles.header, { backgroundColor: theme.surface, borderBottomColor: theme.border }]}>
        <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
          <ArrowLeft size={24} color={theme.primary} />
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: theme.text }]}>{match?.other_user.username}</Text>
        <View style={styles.callButton} />
      </View>

      <FlatList
        ref={flatListRef}
        data={messages}
        renderItem={renderMessage}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.messagesList}
        onContentSizeChange={() => flatListRef.current?.scrollToEnd({ animated: true })}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Text style={[styles.emptyText, { color: theme.text }]}>No messages yet</Text>
            <Text style={[styles.emptySubtext, { color: theme.textSecondary }]}>Start the conversation!</Text>
          </View>
        }
      />

      {uploading && (
        <View style={[styles.uploadingOverlay, { backgroundColor: theme.surface }]}>
          <ActivityIndicator color={theme.primary} />
          <Text style={[styles.uploadingText, { color: theme.text }]}>Uploading image...</Text>
        </View>
      )}

      <View style={[styles.inputContainer, { borderTopColor: theme.border }]}>
        <TouchableOpacity style={styles.iconButton} onPress={() => setShowEmojiPicker(true)}>
          <Smile size={24} color={theme.primary} />
        </TouchableOpacity>
        <TouchableOpacity style={styles.iconButton} onPress={pickImage} disabled={uploading}>
          <ImageIcon size={24} color={uploading ? theme.textTertiary : theme.primary} />
        </TouchableOpacity>
        <TextInput
          style={[styles.input, { backgroundColor: theme.surface, color: theme.text }]}
          placeholder="Type a message..."
          placeholderTextColor={theme.textTertiary}
          value={newMessage}
          onChangeText={setNewMessage}
          multiline
          maxLength={500}
        />
        <TouchableOpacity
          style={[styles.sendButton, { backgroundColor: theme.primary }, (!newMessage.trim() || sending) && styles.sendButtonDisabled]}
          onPress={sendMessage}
          disabled={!newMessage.trim() || sending}
        >
          {sending ? <ActivityIndicator color="#fff" size="small" /> : <Send size={20} color="#fff" />}
        </TouchableOpacity>
      </View>

      <Modal visible={showEmojiPicker} transparent animationType="slide">
        <View style={styles.emojiModal}>
          <View style={[styles.emojiContainer, { backgroundColor: theme.surface }]}>
            <View style={styles.emojiHeader}>
              <Text style={[styles.emojiTitle, { color: theme.text }]}>Feet Emojis</Text>
              <TouchableOpacity onPress={() => setShowEmojiPicker(false)}>
                <X size={24} color={theme.text} />
              </TouchableOpacity>
            </View>
            <View style={styles.emojiGrid}>
              {FEET_EMOJIS.map((emoji, index) => (
                <TouchableOpacity key={index} style={styles.emojiButton} onPress={() => insertEmoji(emoji)}>
                  <Text style={styles.emoji}>{emoji}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        </View>
      </Modal>

      <Modal visible={!!expandedImage} transparent animationType="fade" onRequestClose={() => setExpandedImage(null)}>
        <TouchableOpacity style={styles.imageExpandModal} activeOpacity={1} onPress={() => setExpandedImage(null)}>
          <View style={styles.imageExpandHeader}>
            <TouchableOpacity style={styles.closeButton} onPress={() => setExpandedImage(null)}>
              <X size={28} color="#fff" />
            </TouchableOpacity>
          </View>
          {expandedImage && <Image source={{ uri: expandedImage }} style={styles.expandedImage} resizeMode="contain" />}
        </TouchableOpacity>
      </Modal>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingTop: 60, paddingBottom: 16, paddingHorizontal: 16, borderBottomWidth: 1 },
  backButton: { width: 40, height: 40, justifyContent: 'center' },
  headerTitle: { fontSize: 18, fontWeight: '600', flex: 1, textAlign: 'center' },
  callButton: { width: 40, height: 40 },
  messagesList: { padding: 16, flexGrow: 1 },
  messageContainer: { marginBottom: 12, maxWidth: '80%' },
  ownMessage: { alignSelf: 'flex-end' },
  otherMessage: { alignSelf: 'flex-start' },
  messageBubble: { padding: 12, borderRadius: 16 },
  ownBubble: { backgroundColor: '#0066ff', borderBottomRightRadius: 4 },
  otherBubble: { backgroundColor: '#1a1a1a', borderBottomLeftRadius: 4 },
  messageText: { fontSize: 16, lineHeight: 22, marginBottom: 4 },
  ownText: { color: '#fff' },
  otherText: { color: '#fff' },
  messageTime: { fontSize: 11 },
  ownTime: { color: 'rgba(255, 255, 255, 0.7)' },
  otherTime: { color: '#888' },
  chatImage: { width: 200, height: 200, borderRadius: 12, marginBottom: 4 },
  inputContainer: { flexDirection: 'row', padding: 12, borderTopWidth: 1, alignItems: 'flex-end', gap: 8 },
  iconButton: { width: 40, height: 40, justifyContent: 'center', alignItems: 'center' },
  input: { flex: 1, borderRadius: 20, paddingHorizontal: 16, paddingVertical: 10, fontSize: 16, maxHeight: 100 },
  sendButton: { width: 44, height: 44, borderRadius: 22, justifyContent: 'center', alignItems: 'center' },
  sendButtonDisabled: { opacity: 0.5 },
  uploadingOverlay: { padding: 16, alignItems: 'center', gap: 8 },
  uploadingText: { fontSize: 14 },
  emptyContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', paddingVertical: 80 },
  emptyText: { fontSize: 18, fontWeight: '600', marginBottom: 8 },
  emptySubtext: { fontSize: 14 },
  emojiModal: { flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(0, 0, 0, 0.5)' },
  emojiContainer: { borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 20, maxHeight: '50%' },
  emojiHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  emojiTitle: { fontSize: 18, fontWeight: '600' },
  emojiGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
  emojiButton: { width: 50, height: 50, justifyContent: 'center', alignItems: 'center', borderRadius: 12, backgroundColor: 'rgba(0, 102, 255, 0.1)' },
  emoji: { fontSize: 28 },
  imageExpandModal: { flex: 1, backgroundColor: 'rgba(0, 0, 0, 0.95)', justifyContent: 'center', alignItems: 'center' },
  imageExpandHeader: { position: 'absolute', top: 60, right: 16, zIndex: 1 },
  closeButton: { width: 44, height: 44, borderRadius: 22, backgroundColor: 'rgba(0, 0, 0, 0.5)', justifyContent: 'center', alignItems: 'center' },
  expandedImage: { width: '100%', height: '100%' },
});
