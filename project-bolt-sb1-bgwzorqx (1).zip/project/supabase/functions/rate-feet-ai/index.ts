import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const OPENAI_API_KEY = Deno.env.get('OPENAI_API_KEY');

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const { imageUrl } = await req.json();

    if (!imageUrl) {
      return new Response(
        JSON.stringify({ error: 'Image URL is required' }),
        {
          status: 400,
          headers: {
            ...corsHeaders,
            'Content-Type': 'application/json',
          },
        }
      );
    }

    if (!OPENAI_API_KEY) {
      console.warn('OpenAI API key not configured, using mock validation');
      
      const isFeet = Math.random() > 0.3;
      
      if (!isFeet) {
        return new Response(
          JSON.stringify({ 
            error: 'Invalid image: This does not appear to be a picture of feet. Please upload a clear photo of feet.',
            isFeet: false 
          }),
          {
            status: 400,
            headers: {
              ...corsHeaders,
              'Content-Type': 'application/json',
            },
          }
        );
      }
      
      const rating = Math.random() * 4 + 6;
      const formattedRating = Math.round(rating * 100) / 100;
      
      return new Response(
        JSON.stringify({ rating: formattedRating, isFeet: true }),
        {
          headers: {
            ...corsHeaders,
            'Content-Type': 'application/json',
          },
        }
      );
    }

    const visionResponse = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${OPENAI_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [
          {
            role: 'user',
            content: [
              {
                type: 'text',
                text: 'You are a feet picture validator and rater. First, determine if this image clearly shows human feet (not shoes, socks, or other body parts). If it does not show feet, respond with {"isFeet": false}. If it does show feet, rate them on a scale of 1-10 based on aesthetics, cleanliness, and overall appearance. Respond with {"isFeet": true, "rating": X} where X is a number between 1 and 10.'
              },
              {
                type: 'image_url',
                image_url: {
                  url: imageUrl
                }
              }
            ]
          }
        ],
        max_tokens: 100
      })
    });

    if (!visionResponse.ok) {
      const errorData = await visionResponse.text();
      console.error('OpenAI API error:', errorData);
      throw new Error('Failed to analyze image');
    }

    const visionData = await visionResponse.json();
    const content = visionData.choices[0].message.content;
    
    let result;
    try {
      result = JSON.parse(content);
    } catch (e) {
      const match = content.match(/\{[^}]+\}/);
      if (match) {
        result = JSON.parse(match[0]);
      } else {
        throw new Error('Failed to parse AI response');
      }
    }

    if (!result.isFeet) {
      return new Response(
        JSON.stringify({ 
          error: 'Invalid image: This does not appear to be a picture of feet. Please upload a clear photo of feet.',
          isFeet: false 
        }),
        {
          status: 400,
          headers: {
            ...corsHeaders,
            'Content-Type': 'application/json',
          },
        }
      );
    }

    const rating = Math.max(1, Math.min(10, result.rating));
    const formattedRating = Math.round(rating * 100) / 100;

    return new Response(
      JSON.stringify({ rating: formattedRating, isFeet: true }),
      {
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  } catch (error) {
    console.error('Error:', error);
    return new Response(
      JSON.stringify({ error: error.message || 'Failed to rate image' }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  }
});