/*
  # Enable Realtime for Feed Updates

  1. Changes
    - Enable realtime broadcasting for feet_pics table
    - Enable realtime broadcasting for ratings table
    - This allows the feed to update automatically when new pics are uploaded or rated
  
  2. Security
    - Realtime respects existing RLS policies
    - Only authenticated users can receive updates based on SELECT policies
*/

-- Enable realtime for feet_pics table
ALTER PUBLICATION supabase_realtime ADD TABLE feet_pics;

-- Enable realtime for ratings table
ALTER PUBLICATION supabase_realtime ADD TABLE ratings;
