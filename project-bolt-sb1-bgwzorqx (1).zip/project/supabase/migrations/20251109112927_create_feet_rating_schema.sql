/*
  # Create Feet Rating App Schema

  ## Overview
  This migration creates the complete database schema for a feet picture rating app with AI ratings, 
  premium user ratings, matching system, and chat functionality.

  ## New Tables
  
  ### `profiles`
  - `id` (uuid, primary key) - References auth.users
  - `username` (text, unique) - User's display name
  - `is_premium` (boolean) - Premium subscription status
  - `created_at` (timestamptz) - Account creation timestamp
  - `avatar_url` (text, nullable) - Profile picture URL
  
  ### `feet_pics`
  - `id` (uuid, primary key) - Unique picture identifier
  - `user_id` (uuid) - References profiles(id)
  - `image_url` (text) - URL to the uploaded image
  - `ai_rating` (decimal) - AI-generated rating (0-10)
  - `human_rating_avg` (decimal, nullable) - Average human rating
  - `human_rating_count` (integer) - Number of human ratings
  - `created_at` (timestamptz) - Upload timestamp
  - `updated_at` (timestamptz) - Last update timestamp
  
  ### `ratings`
  - `id` (uuid, primary key) - Unique rating identifier
  - `pic_id` (uuid) - References feet_pics(id)
  - `rater_id` (uuid) - References profiles(id)
  - `rating` (decimal) - Rating value (0-10)
  - `created_at` (timestamptz) - Rating timestamp
  - Unique constraint on (pic_id, rater_id) to prevent duplicate ratings
  
  ### `matches`
  - `id` (uuid, primary key) - Unique match identifier
  - `user1_id` (uuid) - References profiles(id)
  - `user2_id` (uuid) - References profiles(id)
  - `pic1_id` (uuid) - References feet_pics(id)
  - `pic2_id` (uuid) - References feet_pics(id)
  - `created_at` (timestamptz) - Match creation timestamp
  
  ### `messages`
  - `id` (uuid, primary key) - Unique message identifier
  - `match_id` (uuid) - References matches(id)
  - `sender_id` (uuid) - References profiles(id)
  - `content` (text) - Message text
  - `created_at` (timestamptz) - Message timestamp
  - `read` (boolean) - Read status
  
  ## Security
  - Enable RLS on all tables
  - Profiles: Users can read all profiles, update only their own
  - Feet pics: Users can read all, insert their own, update/delete only their own
  - Ratings: Premium users can insert ratings, all can read, users can read their own ratings
  - Matches: Users can read matches they're part of
  - Messages: Users can read/insert messages in their matches
  
  ## Indexes
  - Index on feet_pics.user_id for faster user lookup
  - Index on ratings.pic_id for faster rating aggregation
  - Index on matches.user1_id and matches.user2_id for faster match lookup
  - Index on messages.match_id for faster message retrieval
*/

-- Create profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username text UNIQUE NOT NULL,
  is_premium boolean DEFAULT false,
  avatar_url text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view all profiles"
  ON profiles FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can insert own profile"
  ON profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- Create feet_pics table
CREATE TABLE IF NOT EXISTS feet_pics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  image_url text NOT NULL,
  ai_rating decimal(3,2) NOT NULL CHECK (ai_rating >= 0 AND ai_rating <= 10),
  human_rating_avg decimal(3,2) CHECK (human_rating_avg >= 0 AND human_rating_avg <= 10),
  human_rating_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE feet_pics ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view feet pics"
  ON feet_pics FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can upload own feet pics"
  ON feet_pics FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own feet pics"
  ON feet_pics FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own feet pics"
  ON feet_pics FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_feet_pics_user_id ON feet_pics(user_id);
CREATE INDEX IF NOT EXISTS idx_feet_pics_created_at ON feet_pics(created_at DESC);

-- Create ratings table
CREATE TABLE IF NOT EXISTS ratings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  pic_id uuid NOT NULL REFERENCES feet_pics(id) ON DELETE CASCADE,
  rater_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  rating decimal(3,2) NOT NULL CHECK (rating >= 0 AND rating <= 10),
  created_at timestamptz DEFAULT now(),
  UNIQUE(pic_id, rater_id)
);

ALTER TABLE ratings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view ratings"
  ON ratings FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Premium users can insert ratings"
  ON ratings FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE profiles.id = auth.uid() 
      AND profiles.is_premium = true
    )
    AND auth.uid() = rater_id
    AND NOT EXISTS (
      SELECT 1 FROM feet_pics 
      WHERE feet_pics.id = pic_id 
      AND feet_pics.user_id = auth.uid()
    )
  );

CREATE INDEX IF NOT EXISTS idx_ratings_pic_id ON ratings(pic_id);
CREATE INDEX IF NOT EXISTS idx_ratings_rater_id ON ratings(rater_id);

-- Create function to update human rating average
CREATE OR REPLACE FUNCTION update_human_rating_avg()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE feet_pics
  SET 
    human_rating_avg = (
      SELECT AVG(rating)::decimal(3,2) 
      FROM ratings 
      WHERE pic_id = NEW.pic_id
    ),
    human_rating_count = (
      SELECT COUNT(*) 
      FROM ratings 
      WHERE pic_id = NEW.pic_id
    ),
    updated_at = now()
  WHERE id = NEW.pic_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_human_rating_avg
  AFTER INSERT ON ratings
  FOR EACH ROW
  EXECUTE FUNCTION update_human_rating_avg();

-- Create matches table
CREATE TABLE IF NOT EXISTS matches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user1_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  user2_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  pic1_id uuid NOT NULL REFERENCES feet_pics(id) ON DELETE CASCADE,
  pic2_id uuid NOT NULL REFERENCES feet_pics(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  CHECK (user1_id < user2_id)
);

ALTER TABLE matches ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their matches"
  ON matches FOR SELECT
  TO authenticated
  USING (auth.uid() = user1_id OR auth.uid() = user2_id);

CREATE INDEX IF NOT EXISTS idx_matches_user1_id ON matches(user1_id);
CREATE INDEX IF NOT EXISTS idx_matches_user2_id ON matches(user2_id);

-- Create messages table
CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  match_id uuid NOT NULL REFERENCES matches(id) ON DELETE CASCADE,
  sender_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  content text NOT NULL,
  read boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view messages in their matches"
  ON messages FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM matches 
      WHERE matches.id = match_id 
      AND (matches.user1_id = auth.uid() OR matches.user2_id = auth.uid())
    )
  );

CREATE POLICY "Users can send messages in their matches"
  ON messages FOR INSERT
  TO authenticated
  WITH CHECK (
    auth.uid() = sender_id
    AND EXISTS (
      SELECT 1 FROM matches 
      WHERE matches.id = match_id 
      AND (matches.user1_id = auth.uid() OR matches.user2_id = auth.uid())
    )
  );

CREATE POLICY "Users can update read status on their messages"
  ON messages FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM matches 
      WHERE matches.id = match_id 
      AND (matches.user1_id = auth.uid() OR matches.user2_id = auth.uid())
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM matches 
      WHERE matches.id = match_id 
      AND (matches.user1_id = auth.uid() OR matches.user2_id = auth.uid())
    )
  );

CREATE INDEX IF NOT EXISTS idx_messages_match_id ON messages(match_id);
CREATE INDEX IF NOT EXISTS idx_messages_created_at ON messages(created_at DESC);

-- Create function to check and create matches
CREATE OR REPLACE FUNCTION check_and_create_match()
RETURNS TRIGGER AS $$
DECLARE
  v_rater_id uuid;
  v_pic_owner_id uuid;
  v_rater_pic_id uuid;
  v_rater_pic_rating decimal;
BEGIN
  v_rater_id := NEW.rater_id;
  
  SELECT user_id INTO v_pic_owner_id
  FROM feet_pics
  WHERE id = NEW.pic_id;
  
  IF NEW.rating > 8 THEN
    SELECT fp.id, r.rating INTO v_rater_pic_id, v_rater_pic_rating
    FROM feet_pics fp
    JOIN ratings r ON r.pic_id = fp.id
    WHERE fp.user_id = v_rater_id
      AND r.rater_id = v_pic_owner_id
      AND r.rating > 8
    LIMIT 1;
    
    IF v_rater_pic_id IS NOT NULL THEN
      INSERT INTO matches (user1_id, user2_id, pic1_id, pic2_id)
      VALUES (
        LEAST(v_rater_id, v_pic_owner_id),
        GREATEST(v_rater_id, v_pic_owner_id),
        CASE WHEN v_rater_id < v_pic_owner_id THEN v_rater_pic_id ELSE NEW.pic_id END,
        CASE WHEN v_rater_id < v_pic_owner_id THEN NEW.pic_id ELSE v_rater_pic_id END
      )
      ON CONFLICT DO NOTHING;
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER trigger_check_match
  AFTER INSERT ON ratings
  FOR EACH ROW
  EXECUTE FUNCTION check_and_create_match();