/*
  # Fix Feet Pics Premium Access Policy

  ## Problem
  The feet_pics policy was using a helper function that might cause issues.

  ## Solution
  Simplify to direct subscription_tier check without helper function.

  ## Changes
  - Drop old policy
  - Create new policy with direct checks
  - Users can see their own pics
  - Users can see pics from matches
  - Premium users can see all pics
*/

-- Drop the old policy
DROP POLICY IF EXISTS "Users can view feet pics" ON feet_pics;

-- Drop the helper function
DROP FUNCTION IF EXISTS is_premium_active(uuid);

-- Create new simplified policy
CREATE POLICY "Users can view feet pics"
  ON feet_pics FOR SELECT
  TO authenticated
  USING (
    -- Own pics
    user_id = auth.uid()
    -- OR premium with active subscription
    OR EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.subscription_tier = 'premium'
      AND (profiles.subscription_expires_at IS NULL OR profiles.subscription_expires_at > now())
    )
    -- OR pics from matches
    OR EXISTS (
      SELECT 1 FROM matches
      WHERE (user1_id = auth.uid() AND user2_id = feet_pics.user_id)
         OR (user2_id = auth.uid() AND user1_id = feet_pics.user_id)
    )
  );