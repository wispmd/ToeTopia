/*
  # Modern Gender and Orientation System

  ## Overview
  Implements a flexible, inclusive gender and orientation system inspired by
  modern dating apps like Tinder, Hinge, and OkCupid.

  ## Changes to `profiles` table
  
  ### Remove old fields
  - Remove simple `gender` and `orientation` text fields
  
  ### Add new fields
  - `gender_identities` (text[]) - Array of gender identities
  - `gender_display` (text) - How to show on profile (optional)
  - `interested_in_genders` (text[]) - Genders they want to match with
  - `pronouns` (text) - User's pronouns (optional)
  - `custom_gender` (text) - Custom gender if "self-describe" selected
  - `custom_orientation` (text) - Custom orientation if "self-describe" selected

  ## Gender Identity Options
  - man
  - woman
  - non-binary
  - trans-man
  - trans-woman
  - genderqueer
  - self-describe
  - prefer-not-to-say

  ## Orientation/Interested In Options
  - men
  - women
  - non-binary-people
  - everyone
  - self-describe

  ## Pronouns Options
  - he/him
  - she/her
  - they/them
  - other

  ## Matching Logic
  Users match when:
  1. User A's interested_in_genders overlaps with User B's gender_identities
  2. User B's interested_in_genders overlaps with User A's gender_identities
  3. Both users rate each other 8+
*/

-- Drop old columns (if they still exist as text)
DO $$
BEGIN
  -- Only drop if they're simple text columns
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles'
    AND column_name = 'gender'
    AND data_type = 'text'
  ) THEN
    ALTER TABLE profiles DROP COLUMN gender;
  END IF;

  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles'
    AND column_name = 'orientation'
    AND data_type = 'text'
  ) THEN
    ALTER TABLE profiles DROP COLUMN orientation;
  END IF;
END $$;

-- Add new columns
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'gender_identities'
  ) THEN
    ALTER TABLE profiles ADD COLUMN gender_identities text[] DEFAULT '{}';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'gender_display'
  ) THEN
    ALTER TABLE profiles ADD COLUMN gender_display text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'interested_in_genders'
  ) THEN
    ALTER TABLE profiles ADD COLUMN interested_in_genders text[] DEFAULT '{}';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'pronouns'
  ) THEN
    ALTER TABLE profiles ADD COLUMN pronouns text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'custom_gender'
  ) THEN
    ALTER TABLE profiles ADD COLUMN custom_gender text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'custom_orientation'
  ) THEN
    ALTER TABLE profiles ADD COLUMN custom_orientation text;
  END IF;
END $$;

-- Create helper function to check if gender arrays match
CREATE OR REPLACE FUNCTION check_gender_compatibility(
  user_a_genders text[],
  user_a_interested text[],
  user_b_genders text[],
  user_b_interested text[]
)
RETURNS boolean AS $$
BEGIN
  -- Check if user A is interested in any of user B's genders
  -- AND user B is interested in any of user A's genders
  -- OR either person is interested in "everyone"
  RETURN (
    (
      user_a_interested && user_b_genders
      AND user_b_interested && user_a_genders
    )
    OR 'everyone' = ANY(user_a_interested)
    OR 'everyone' = ANY(user_b_interested)
  );
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- Update the match creation trigger to use new gender compatibility
CREATE OR REPLACE FUNCTION check_and_create_match()
RETURNS TRIGGER AS $$
DECLARE
  v_rater_id uuid;
  v_pic_owner_id uuid;
  v_rater_pic_id uuid;
  v_rater_pic_rating decimal;
  v_rater_profile RECORD;
  v_owner_profile RECORD;
BEGIN
  v_rater_id := NEW.rater_id;
  
  SELECT user_id INTO v_pic_owner_id
  FROM feet_pics
  WHERE id = NEW.pic_id;
  
  IF NEW.rating >= 8 THEN
    -- Get profiles for gender compatibility check
    SELECT gender_identities, interested_in_genders INTO v_rater_profile
    FROM profiles WHERE id = v_rater_id;
    
    SELECT gender_identities, interested_in_genders INTO v_owner_profile
    FROM profiles WHERE id = v_pic_owner_id;
    
    -- Check if there's a reciprocal high rating
    SELECT fp.id, r.rating INTO v_rater_pic_id, v_rater_pic_rating
    FROM feet_pics fp
    JOIN ratings r ON r.pic_id = fp.id
    WHERE fp.user_id = v_rater_id
      AND r.rater_id = v_pic_owner_id
      AND r.rating >= 8
    LIMIT 1;
    
    -- If reciprocal rating exists and genders are compatible, create match
    IF v_rater_pic_id IS NOT NULL THEN
      -- Check gender compatibility
      IF check_gender_compatibility(
        v_rater_profile.gender_identities,
        v_rater_profile.interested_in_genders,
        v_owner_profile.gender_identities,
        v_owner_profile.interested_in_genders
      ) THEN
        INSERT INTO matches (user1_id, user2_id, pic1_id, pic2_id)
        VALUES (
          LEAST(v_rater_id, v_pic_owner_id),
          GREATEST(v_rater_id, v_pic_owner_id),
          CASE WHEN v_rater_id < v_pic_owner_id THEN v_rater_pic_id ELSE NEW.pic_id END,
          CASE WHEN v_rater_id < v_pic_owner_id THEN NEW.pic_id ELSE v_rater_pic_id END
        )
        ON CONFLICT DO NOTHING;
      END IF;
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;