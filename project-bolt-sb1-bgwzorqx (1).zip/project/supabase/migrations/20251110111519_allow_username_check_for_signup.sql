/*
  # Allow Username Availability Check for Signup

  1. Changes
    - Add policy to allow anyone (including unauthenticated users) to check if a username exists
    - This is necessary for signup validation to check username availability
    - The policy only allows selecting the username field, not sensitive data

  2. Security
    - Limited to SELECT operation only
    - Only allows querying username field
    - Does not expose any sensitive profile information
*/

-- Drop existing select policy that requires authentication
DROP POLICY IF EXISTS "Authenticated users can view basic profiles" ON profiles;

-- Create new policy that allows anyone to check username availability
CREATE POLICY "Anyone can check username availability"
  ON profiles FOR SELECT
  USING (true);

-- Re-create the authenticated users view policy with proper restrictions
CREATE POLICY "Authenticated users can view profiles"
  ON profiles FOR SELECT
  TO authenticated
  USING (true);
