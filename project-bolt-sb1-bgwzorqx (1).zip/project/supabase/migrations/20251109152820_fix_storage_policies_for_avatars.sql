/*
  # Fix Storage Policies for Avatars

  ## Changes
  - Update storage policies to allow uploads to both 'feet-pics' and 'avatars' folders
  - Optimize existing policies with (select auth.uid())

  ## Security
  - Authenticated users can upload to feet-pics or avatars folders
  - Public read access maintained
  - Users can only delete their own images
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Authenticated users can upload images" ON storage.objects;
DROP POLICY IF EXISTS "Users can delete own images" ON storage.objects;

-- Recreate upload policy to allow both feet-pics and avatars folders
CREATE POLICY "Authenticated users can upload images"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (
    bucket_id = 'images'
    AND (
      (storage.foldername(name))[1] = 'feet-pics'
      OR (storage.foldername(name))[1] = 'avatars'
    )
  );

-- Recreate delete policy with optimized auth.uid()
CREATE POLICY "Users can delete own images"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (
    bucket_id = 'images'
    AND (select auth.uid())::text = (storage.foldername(name))[1]
  );