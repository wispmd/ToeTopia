/*
  # Fix Infinite Recursion in Profiles RLS Policy

  ## Problem
  The profiles SELECT policy was causing infinite recursion because it was
  checking premium status by querying the same profiles table.

  ## Solution
  Simplify the policy to allow:
  - Users can always see their own profile
  - Users can see profiles in their matches
  - Everyone can see basic profile info (we'll handle pic access separately)

  ## Changes
  - Drop and recreate the profiles SELECT policy without recursion
  - Ensure clean policy structure
*/

-- Drop the problematic policy
DROP POLICY IF EXISTS "Users can view profiles" ON profiles;

-- Create a simpler, non-recursive policy
CREATE POLICY "Users can view profiles"
  ON profiles FOR SELECT
  TO authenticated
  USING (
    id = auth.uid()
    OR EXISTS (
      SELECT 1 FROM matches
      WHERE (user1_id = auth.uid() AND user2_id = profiles.id)
         OR (user2_id = auth.uid() AND user1_id = profiles.id)
    )
  );

-- Note: The premium check for viewing full galleries is handled in feet_pics policy
-- This allows basic profile viewing for matches and self