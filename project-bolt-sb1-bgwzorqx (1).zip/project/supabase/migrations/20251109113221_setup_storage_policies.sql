/*
  # Setup Storage Policies for Images Bucket

  ## Overview
  This migration creates storage policies for the images bucket to allow authenticated users
  to upload and access images.

  ## Security
  - Allow authenticated users to upload images to their own folder
  - Allow public read access to all images
  - Restrict updates and deletes to image owners
*/

CREATE POLICY "Authenticated users can upload images"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (
    bucket_id = 'images'
    AND (storage.foldername(name))[1] = 'feet-pics'
  );

CREATE POLICY "Anyone can view images"
  ON storage.objects FOR SELECT
  TO public
  USING (bucket_id = 'images');

CREATE POLICY "Users can delete own images"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (
    bucket_id = 'images'
    AND auth.uid()::text = (storage.foldername(name))[1]
  );