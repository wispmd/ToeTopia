/*
  # Allow Basic Profile Viewing in Feed

  1. Changes
    - Update profiles RLS policy to allow viewing basic profile info (username, avatar)
    - All authenticated users can see basic profile data in the feed
    - Full profile details still require premium or match status
  
  2. Security
    - Maintains authentication requirement
    - Allows basic profile info to be visible for feed display
    - Preserves privacy for sensitive profile data
*/

-- Drop the restrictive view policy
DROP POLICY IF EXISTS "Users can view profiles" ON profiles;

-- Create a new policy that allows authenticated users to view all basic profiles
CREATE POLICY "Authenticated users can view basic profiles"
  ON profiles
  FOR SELECT
  TO authenticated
  USING (true);