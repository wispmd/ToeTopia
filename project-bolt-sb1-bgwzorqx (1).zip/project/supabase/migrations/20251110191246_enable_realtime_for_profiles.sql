/*
  # Enable realtime for profiles table

  1. Changes
    - Enable realtime updates for the profiles table
    - This allows clients to subscribe to profile changes in real-time
  
  2. Security
    - No changes to RLS policies
    - Clients can only receive updates for profiles they can already read
*/

ALTER PUBLICATION supabase_realtime ADD TABLE profiles;