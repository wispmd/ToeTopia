/*
  # Fix Rating Threshold to >= 8

  1. Changes
    - Update match creation trigger to use >= 8 instead of > 8
    - This means ratings of 8, 9, or 10 will create matches
  
  2. Notes
    - Previously only ratings above 8 (9 or 10) would create matches
    - Now ratings of 8 or higher will create matches
*/

-- Update the match creation function to use >= 8 instead of > 8
CREATE OR REPLACE FUNCTION check_and_create_match()
RETURNS TRIGGER AS $$
DECLARE
  v_rater_id uuid;
  v_pic_owner_id uuid;
  v_has_mutual_high_rating boolean;
BEGIN
  v_rater_id := NEW.rater_id;
  
  -- Get the picture owner
  SELECT user_id INTO v_pic_owner_id
  FROM feet_pics
  WHERE id = NEW.pic_id;
  
  -- Only check if this rating is >= 8 (8 or higher)
  IF NEW.rating >= 8 THEN
    -- Check if the picture owner has also rated any of the rater's pictures >= 8
    SELECT EXISTS (
      SELECT 1
      FROM feet_pics fp
      JOIN ratings r ON r.pic_id = fp.id
      WHERE fp.user_id = v_rater_id
        AND r.rater_id = v_pic_owner_id
        AND r.rating >= 8
    ) INTO v_has_mutual_high_rating;
    
    -- If mutual high ratings exist, create a match (if it doesn't already exist)
    IF v_has_mutual_high_rating THEN
      INSERT INTO matches (user1_id, user2_id)
      VALUES (
        LEAST(v_rater_id, v_pic_owner_id),
        GREATEST(v_rater_id, v_pic_owner_id)
      )
      ON CONFLICT (user1_id, user2_id) DO NOTHING;
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
