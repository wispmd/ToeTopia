/*
  # Fix Feed Visibility for Free Users

  1. Changes
    - Update RLS policy on feet_pics to allow free users to view a limited feed
    - Free users can see pics from other users (but not rate them)
    - Keep restrictions for premium-only features intact
  
  2. Security
    - Maintains authentication requirement
    - Free users can only view, not rate
    - Premium users retain all privileges
*/

-- Drop the restrictive policy
DROP POLICY IF EXISTS "Users can view feet pics" ON feet_pics;

-- Create a new policy that allows authenticated users to view all pics
CREATE POLICY "Authenticated users can view all feet pics"
  ON feet_pics
  FOR SELECT
  TO authenticated
  USING (true);