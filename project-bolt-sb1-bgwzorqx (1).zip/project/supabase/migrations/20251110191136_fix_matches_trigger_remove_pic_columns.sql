/*
  # Fix matches trigger to remove pic1_id and pic2_id references

  1. Changes
    - Update create_mutual_match_on_rating trigger function to not use pic1_id and pic2_id columns
    - Matches are now per user pair, not per picture pair
  
  2. Security
    - No changes to RLS policies needed
*/

CREATE OR REPLACE FUNCTION create_mutual_match_on_rating()
RETURNS TRIGGER AS $$
DECLARE
  v_rater_id uuid;
  v_pic_owner_id uuid;
  v_rater_rating numeric;
  v_owner_rating numeric;
  v_rater_pic_id uuid;
  v_rater_profile RECORD;
  v_owner_profile RECORD;
BEGIN
  v_rater_id := NEW.rater_id;
  
  SELECT user_id INTO v_pic_owner_id
  FROM feet_pics
  WHERE id = NEW.pic_id;
  
  IF v_pic_owner_id IS NULL THEN
    RETURN NEW;
  END IF;
  
  IF v_rater_id = v_pic_owner_id THEN
    RETURN NEW;
  END IF;
  
  v_rater_rating := NEW.rating;
  
  SELECT AVG(r.rating) INTO v_owner_rating
  FROM ratings r
  JOIN feet_pics fp ON r.pic_id = fp.id
  WHERE r.rater_id = v_pic_owner_id
    AND fp.user_id = v_rater_id;
  
  IF v_rater_rating >= 8 AND (v_owner_rating >= 8 OR v_owner_rating IS NOT NULL AND v_owner_rating >= 8) THEN
    SELECT fp.id INTO v_rater_pic_id
    FROM feet_pics fp
    JOIN ratings r ON fp.id = r.pic_id
    WHERE fp.user_id = v_rater_id
      AND r.rater_id = v_pic_owner_id
    LIMIT 1;

    SELECT * INTO v_rater_profile FROM profiles WHERE id = v_rater_id;
    SELECT * INTO v_owner_profile FROM profiles WHERE id = v_pic_owner_id;

    IF v_rater_profile.gender_identities IS NULL 
       OR v_rater_profile.interested_in_genders IS NULL
       OR v_owner_profile.gender_identities IS NULL 
       OR v_owner_profile.interested_in_genders IS NULL THEN
      RETURN NEW;
    END IF;

    IF v_rater_pic_id IS NOT NULL THEN
      IF check_gender_compatibility(
        v_rater_profile.gender_identities,
        v_rater_profile.interested_in_genders,
        v_owner_profile.gender_identities,
        v_owner_profile.interested_in_genders
      ) THEN
        INSERT INTO matches (user1_id, user2_id)
        VALUES (
          LEAST(v_rater_id, v_pic_owner_id),
          GREATEST(v_rater_id, v_pic_owner_id)
        )
        ON CONFLICT DO NOTHING;
      END IF;
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;