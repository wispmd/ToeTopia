/*
  # Fix Matches to be Unique Per User Pair

  1. Changes
    - Remove duplicate matches (keep the oldest by created_at)
    - Remove pic1_id and pic2_id columns (matches should be per user, not per picture)
    - Add unique constraint on user1_id and user2_id combination
    - Update the match creation trigger to only create one match per user pair
  
  2. Security
    - Maintains existing RLS policies
    - No security changes needed
    
  3. Notes
    - This ensures users only have ONE chat per matched user
    - Multiple picture ratings between the same users don't create duplicate matches
*/

-- Drop the existing trigger first
DROP TRIGGER IF EXISTS trigger_check_match ON ratings;

-- Remove duplicate matches, keeping only the oldest one (by created_at) for each user pair
DELETE FROM matches m1
WHERE m1.ctid NOT IN (
  SELECT MIN(m2.ctid)
  FROM matches m2
  GROUP BY m2.user1_id, m2.user2_id
);

-- Alter the matches table to remove picture references and add unique constraint
DO $$
BEGIN
  -- Drop pic1_id if it exists
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'matches' AND column_name = 'pic1_id'
  ) THEN
    ALTER TABLE matches DROP COLUMN pic1_id;
  END IF;

  -- Drop pic2_id if it exists
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'matches' AND column_name = 'pic2_id'
  ) THEN
    ALTER TABLE matches DROP COLUMN pic2_id;
  END IF;

  -- Add unique constraint on user pair if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname = 'matches_user_pair_unique'
  ) THEN
    ALTER TABLE matches ADD CONSTRAINT matches_user_pair_unique UNIQUE (user1_id, user2_id);
  END IF;
END $$;

-- Update the match creation function
CREATE OR REPLACE FUNCTION check_and_create_match()
RETURNS TRIGGER AS $$
DECLARE
  v_rater_id uuid;
  v_pic_owner_id uuid;
  v_has_mutual_high_rating boolean;
BEGIN
  v_rater_id := NEW.rater_id;
  
  -- Get the picture owner
  SELECT user_id INTO v_pic_owner_id
  FROM feet_pics
  WHERE id = NEW.pic_id;
  
  -- Only check if this rating is > 8
  IF NEW.rating > 8 THEN
    -- Check if the picture owner has also rated any of the rater's pictures > 8
    SELECT EXISTS (
      SELECT 1
      FROM feet_pics fp
      JOIN ratings r ON r.pic_id = fp.id
      WHERE fp.user_id = v_rater_id
        AND r.rater_id = v_pic_owner_id
        AND r.rating > 8
    ) INTO v_has_mutual_high_rating;
    
    -- If mutual high ratings exist, create a match (if it doesn't already exist)
    IF v_has_mutual_high_rating THEN
      INSERT INTO matches (user1_id, user2_id)
      VALUES (
        LEAST(v_rater_id, v_pic_owner_id),
        GREATEST(v_rater_id, v_pic_owner_id)
      )
      ON CONFLICT (user1_id, user2_id) DO NOTHING;
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Recreate the trigger
CREATE TRIGGER trigger_check_match
  AFTER INSERT ON ratings
  FOR EACH ROW
  EXECUTE FUNCTION check_and_create_match();
