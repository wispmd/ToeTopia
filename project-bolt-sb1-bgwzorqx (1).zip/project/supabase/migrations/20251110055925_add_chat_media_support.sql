/*
  # Add Chat Media Support

  ## Overview
  Extends the messaging system to support:
  - Image sharing within chats (won't appear in feed)
  - Video call tracking
  - Message types (text, image, system)

  ## Changes to `messages` table
  
  ### Add new columns
  - `message_type` (text) - Type: 'text', 'image', 'system'
  - `image_url` (text) - URL for shared images
  - `image_path` (text) - Storage path for images
  
  ## Create `call_logs` table
  
  ### Columns
  - `id` (uuid, primary key)
  - `match_id` (uuid) - Reference to matches
  - `caller_id` (uuid) - User who initiated call
  - `receiver_id` (uuid) - User who received call
  - `started_at` (timestamptz) - When call started
  - `ended_at` (timestamptz) - When call ended
  - `duration_seconds` (int) - Call duration
  - `status` (text) - 'completed', 'missed', 'rejected'
  - `created_at` (timestamptz)

  ## Storage bucket for chat images
  - Create `chat-images` bucket
  - Set up RLS policies

  ## Security
  - Only matched users can share images with each other
  - Only premium users can initiate calls
  - Images are private to the match
*/

-- Add columns to messages table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'messages' AND column_name = 'message_type'
  ) THEN
    ALTER TABLE messages ADD COLUMN message_type text DEFAULT 'text';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'messages' AND column_name = 'image_url'
  ) THEN
    ALTER TABLE messages ADD COLUMN image_url text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'messages' AND column_name = 'image_path'
  ) THEN
    ALTER TABLE messages ADD COLUMN image_path text;
  END IF;
END $$;

-- Create call_logs table
CREATE TABLE IF NOT EXISTS call_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  match_id uuid NOT NULL REFERENCES matches(id) ON DELETE CASCADE,
  caller_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  receiver_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  started_at timestamptz DEFAULT now(),
  ended_at timestamptz,
  duration_seconds int,
  status text DEFAULT 'completed',
  created_at timestamptz DEFAULT now()
);

-- Enable RLS on call_logs
ALTER TABLE call_logs ENABLE ROW LEVEL SECURITY;

-- Create policies for call_logs
CREATE POLICY "Users can view their own call logs"
  ON call_logs FOR SELECT
  TO authenticated
  USING (caller_id = auth.uid() OR receiver_id = auth.uid());

CREATE POLICY "Users can create call logs"
  ON call_logs FOR INSERT
  TO authenticated
  WITH CHECK (caller_id = auth.uid() OR receiver_id = auth.uid());

CREATE POLICY "Users can update their own call logs"
  ON call_logs FOR UPDATE
  TO authenticated
  USING (caller_id = auth.uid() OR receiver_id = auth.uid())
  WITH CHECK (caller_id = auth.uid() OR receiver_id = auth.uid());

-- Create storage bucket for chat images
INSERT INTO storage.buckets (id, name, public)
VALUES ('chat-images', 'chat-images', false)
ON CONFLICT (id) DO NOTHING;

-- Storage policies for chat images
CREATE POLICY "Users can upload chat images"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (
    bucket_id = 'chat-images'
    AND auth.uid()::text = (storage.foldername(name))[1]
  );

CREATE POLICY "Users can view chat images from their matches"
  ON storage.objects FOR SELECT
  TO authenticated
  USING (
    bucket_id = 'chat-images'
    AND (
      -- Can view own images
      auth.uid()::text = (storage.foldername(name))[1]
      -- Or images from matches
      OR EXISTS (
        SELECT 1 FROM matches
        WHERE (user1_id = auth.uid() OR user2_id = auth.uid())
        AND ((storage.foldername(name))[1] = user1_id::text OR (storage.foldername(name))[1] = user2_id::text)
      )
    )
  );

CREATE POLICY "Users can delete their own chat images"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (
    bucket_id = 'chat-images'
    AND auth.uid()::text = (storage.foldername(name))[1]
  );

-- Add index for better performance
CREATE INDEX IF NOT EXISTS idx_call_logs_match ON call_logs(match_id);
CREATE INDEX IF NOT EXISTS idx_call_logs_users ON call_logs(caller_id, receiver_id);
CREATE INDEX IF NOT EXISTS idx_messages_type ON messages(message_type);