/*
  # Fix Rating Decimal Precision

  1. Changes
    - Update ratings table: change rating column from decimal(3,2) to decimal(4,2) to allow 10.00
    - Update feet_pics table: change ai_rating and human_rating_avg from decimal(3,2) to decimal(4,2)
  
  2. Reason
    - decimal(3,2) only allows values up to 9.99 (3 total digits, 2 after decimal)
    - decimal(4,2) allows values up to 99.99, which properly supports ratings from 0.00 to 10.00
*/

-- Update ratings table
ALTER TABLE ratings 
  ALTER COLUMN rating TYPE decimal(4,2);

-- Update feet_pics table
ALTER TABLE feet_pics 
  ALTER COLUMN ai_rating TYPE decimal(4,2),
  ALTER COLUMN human_rating_avg TYPE decimal(4,2);
