/*
  # Fix Security and Performance Issues

  ## Changes Made

  ### 1. Add Missing Foreign Key Indexes
  - Add index on matches.pic1_id for faster lookups
  - Add index on matches.pic2_id for faster lookups
  - Add index on messages.sender_id for faster lookups

  ### 2. Optimize RLS Policies
  Replace `auth.uid()` with `(select auth.uid())` in all policies to prevent re-evaluation
  for each row, improving query performance at scale.

  Affected policies:
  - profiles: Users can update own profile
  - profiles: Users can insert own profile
  - feet_pics: Users can upload own feet pics
  - feet_pics: Users can update own feet pics
  - feet_pics: Users can delete own feet pics
  - ratings: Premium users can insert ratings
  - matches: Users can view their matches
  - messages: Users can view messages in their matches
  - messages: Users can send messages in their matches
  - messages: Users can update read status on their messages

  ### 3. Fix Function Search Path Issues
  Add explicit search_path to functions to prevent mutable search_path security issues:
  - update_human_rating_avg()
  - check_and_create_match()

  ### 4. Remove Unused Indexes
  - Drop idx_messages_match_id (redundant with foreign key)
  - Drop idx_messages_created_at (not used in queries)

  ## Security Notes
  - All changes maintain existing security model
  - Performance improvements do not weaken RLS policies
  - Functions are set to SECURITY DEFINER with explicit search_path
*/

-- Add missing foreign key indexes
CREATE INDEX IF NOT EXISTS idx_matches_pic1_id ON matches(pic1_id);
CREATE INDEX IF NOT EXISTS idx_matches_pic2_id ON matches(pic2_id);
CREATE INDEX IF NOT EXISTS idx_messages_sender_id ON messages(sender_id);

-- Drop existing policies to recreate with optimized auth.uid()
DROP POLICY IF EXISTS "Users can update own profile" ON profiles;
DROP POLICY IF EXISTS "Users can insert own profile" ON profiles;
DROP POLICY IF EXISTS "Users can upload own feet pics" ON feet_pics;
DROP POLICY IF EXISTS "Users can update own feet pics" ON feet_pics;
DROP POLICY IF EXISTS "Users can delete own feet pics" ON feet_pics;
DROP POLICY IF EXISTS "Premium users can insert ratings" ON ratings;
DROP POLICY IF EXISTS "Users can view their matches" ON matches;
DROP POLICY IF EXISTS "Users can view messages in their matches" ON messages;
DROP POLICY IF EXISTS "Users can send messages in their matches" ON messages;
DROP POLICY IF EXISTS "Users can update read status on their messages" ON messages;

-- Recreate profiles policies with optimized auth.uid()
CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING ((select auth.uid()) = id)
  WITH CHECK ((select auth.uid()) = id);

CREATE POLICY "Users can insert own profile"
  ON profiles FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = id);

-- Recreate feet_pics policies with optimized auth.uid()
CREATE POLICY "Users can upload own feet pics"
  ON feet_pics FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users can update own feet pics"
  ON feet_pics FOR UPDATE
  TO authenticated
  USING ((select auth.uid()) = user_id)
  WITH CHECK ((select auth.uid()) = user_id);

CREATE POLICY "Users can delete own feet pics"
  ON feet_pics FOR DELETE
  TO authenticated
  USING ((select auth.uid()) = user_id);

-- Recreate ratings policy with optimized auth.uid()
CREATE POLICY "Premium users can insert ratings"
  ON ratings FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE profiles.id = (select auth.uid()) 
      AND profiles.is_premium = true
    )
    AND (select auth.uid()) = rater_id
    AND NOT EXISTS (
      SELECT 1 FROM feet_pics 
      WHERE feet_pics.id = pic_id 
      AND feet_pics.user_id = (select auth.uid())
    )
  );

-- Recreate matches policy with optimized auth.uid()
CREATE POLICY "Users can view their matches"
  ON matches FOR SELECT
  TO authenticated
  USING ((select auth.uid()) = user1_id OR (select auth.uid()) = user2_id);

-- Recreate messages policies with optimized auth.uid()
CREATE POLICY "Users can view messages in their matches"
  ON messages FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM matches 
      WHERE matches.id = match_id 
      AND (matches.user1_id = (select auth.uid()) OR matches.user2_id = (select auth.uid()))
    )
  );

CREATE POLICY "Users can send messages in their matches"
  ON messages FOR INSERT
  TO authenticated
  WITH CHECK (
    (select auth.uid()) = sender_id
    AND EXISTS (
      SELECT 1 FROM matches 
      WHERE matches.id = match_id 
      AND (matches.user1_id = (select auth.uid()) OR matches.user2_id = (select auth.uid()))
    )
  );

CREATE POLICY "Users can update read status on their messages"
  ON messages FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM matches 
      WHERE matches.id = match_id 
      AND (matches.user1_id = (select auth.uid()) OR matches.user2_id = (select auth.uid()))
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM matches 
      WHERE matches.id = match_id 
      AND (matches.user1_id = (select auth.uid()) OR matches.user2_id = (select auth.uid()))
    )
  );

-- Fix function search path issues
CREATE OR REPLACE FUNCTION update_human_rating_avg()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE feet_pics
  SET 
    human_rating_avg = (
      SELECT AVG(rating)::decimal(3,2) 
      FROM ratings 
      WHERE pic_id = NEW.pic_id
    ),
    human_rating_count = (
      SELECT COUNT(*) 
      FROM ratings 
      WHERE pic_id = NEW.pic_id
    ),
    updated_at = now()
  WHERE id = NEW.pic_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = public, pg_temp;

CREATE OR REPLACE FUNCTION check_and_create_match()
RETURNS TRIGGER AS $$
DECLARE
  v_rater_id uuid;
  v_pic_owner_id uuid;
  v_rater_pic_id uuid;
  v_rater_pic_rating decimal;
BEGIN
  v_rater_id := NEW.rater_id;
  
  SELECT user_id INTO v_pic_owner_id
  FROM feet_pics
  WHERE id = NEW.pic_id;
  
  IF NEW.rating > 8 THEN
    SELECT fp.id, r.rating INTO v_rater_pic_id, v_rater_pic_rating
    FROM feet_pics fp
    JOIN ratings r ON r.pic_id = fp.id
    WHERE fp.user_id = v_rater_id
      AND r.rater_id = v_pic_owner_id
      AND r.rating > 8
    LIMIT 1;
    
    IF v_rater_pic_id IS NOT NULL THEN
      INSERT INTO matches (user1_id, user2_id, pic1_id, pic2_id)
      VALUES (
        LEAST(v_rater_id, v_pic_owner_id),
        GREATEST(v_rater_id, v_pic_owner_id),
        CASE WHEN v_rater_id < v_pic_owner_id THEN v_rater_pic_id ELSE NEW.pic_id END,
        CASE WHEN v_rater_id < v_pic_owner_id THEN NEW.pic_id ELSE v_rater_pic_id END
      )
      ON CONFLICT DO NOTHING;
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = public, pg_temp;

-- Remove unused indexes
DROP INDEX IF EXISTS idx_messages_match_id;
DROP INDEX IF EXISTS idx_messages_created_at;