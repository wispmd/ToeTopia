export const lightTheme = {
  background: '#FAF9FF',
  secondaryBackground: '#F3F1FF',
  tertiaryBackground: '#EBE7FF',
  surface: '#FFFFFF',
  surfaceElevated: '#FFFFFF',

  primary: '#8B5CF6',
  primaryLight: '#A78BFA',
  primaryDark: '#7C3AED',

  secondary: '#EC4899',
  secondaryLight: '#F472B6',

  accent: '#6366F1',
  accentLight: '#818CF8',

  success: '#10B981',
  warning: '#F59E0B',
  error: '#EF4444',

  text: '#1F1B2E',
  textSecondary: '#4C4560',
  textTertiary: '#9691A4',
  textQuaternary: '#C7C3D0',

  border: '#E9E5F5',
  borderLight: '#F3F1FF',

  shadow: 'rgba(139, 92, 246, 0.15)',
  shadowDark: 'rgba(139, 92, 246, 0.25)',

  overlay: 'rgba(31, 27, 46, 0.4)',

  gradient1: ['#8B5CF6', '#6366F1'],
  gradient2: ['#EC4899', '#F472B6'],
  gradient3: ['#A78BFA', '#C084FC'],
  gradient4: ['#C084FC', '#EC4899'],
};

export const darkTheme = {
  background: '#0D0B1E',
  secondaryBackground: '#1A1635',
  tertiaryBackground: '#251F47',
  surface: '#1A1635',
  surfaceElevated: '#251F47',

  primary: '#A78BFA',
  primaryLight: '#C4B5FD',
  primaryDark: '#8B5CF6',

  secondary: '#F472B6',
  secondaryLight: '#F9A8D4',

  accent: '#818CF8',
  accentLight: '#A5B4FC',

  success: '#34D399',
  warning: '#FBBF24',
  error: '#F87171',

  text: '#F3F4F6',
  textSecondary: '#E5E7EB',
  textTertiary: '#9CA3AF',
  textQuaternary: '#6B7280',

  border: '#312E51',
  borderLight: '#3F3A5E',

  shadow: 'rgba(139, 92, 246, 0.3)',
  shadowDark: 'rgba(139, 92, 246, 0.5)',

  overlay: 'rgba(13, 11, 30, 0.8)',

  gradient1: ['#8B5CF6', '#6366F1'],
  gradient2: ['#A78BFA', '#F472B6'],
  gradient3: ['#818CF8', '#C084FC'],
  gradient4: ['#C084FC', '#F472B6'],
};

export type Theme = typeof lightTheme;
